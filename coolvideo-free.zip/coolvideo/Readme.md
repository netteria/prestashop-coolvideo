# Cool Video Free - user guide

Cool Video Free adds one YouTube video to each product gallery. There is no
limit on the number of products that can use the module.

## Free features

- one saved YouTube video per product;
- the video is placed at the end of the product gallery;
- responsive click-to-play presentation;
- enable, disable and delete controls;
- PrestaShop 1.7, 8 and 9 support with the gallery integrations available in
  Cool Video.

The product panel also displays locked controls marked as PRO, allowing the
merchant to compare editions without leaving the product editor.

## Installing Free

1. Open **Module Manager** in the PrestaShop back office.
2. Select **Upload a module**.
3. Choose `coolvideo-free.zip`.
4. Open a product and find Cool Video in its **Modules** section.
5. Paste the public URL of one YouTube video and select **Add video**.

Standard YouTube, `youtu.be`, embed, Shorts and Live URLs are supported. The
video must be publicly accessible and allow embedding.

## Free limitations

- Vimeo and Dailymotion require PRO;
- a second video for the same product requires PRO;
- the video remains at the end of the gallery;
- autoplay and product-listing presentation are disabled.

A valid Vimeo or Dailymotion URL is recognised, but the product panel explains
that the service requires PRO.

## Upgrading Free to PRO

Do not uninstall Free. Uninstalling removes the saved product-video
assignments.

1. Purchase Cool Video PRO.
2. Upload the supplied PRO archive over the installed Free edition in Module
   Manager.
3. Wait for the upgrade to finish.
4. Open Cool Video configuration and activate the license key.

Existing videos remain saved. After activation you can change their gallery
position, enable autoplay, add more videos and display videos on product
listings.

