# Cool Video Free - instrukcja użytkownika

Cool Video Free dodaje jeden film YouTube do galerii każdego produktu. Liczba
produktów korzystających z modułu nie jest ograniczona.

## Funkcje wersji Free

- jeden zapisany film YouTube na produkt;
- film umieszczony na końcu galerii produktu;
- responsywne odtwarzanie po kliknięciu;
- włączanie, wyłączanie i usuwanie filmu;
- obsługa PrestaShop 1.7, 8 i 9 oraz integracji galerii dostępnych w Cool Video.

W panelu produktu widoczne są również funkcje oznaczone jako dostępne w PRO.
Pozwala to porównać edycje bez opuszczania konfiguracji produktu.

## Instalacja Free

1. Otwórz **Menedżer modułów** w panelu PrestaShop.
2. Wybierz **Załaduj moduł**.
3. Wskaż archiwum `coolvideo-free.zip`.
4. Otwórz produkt i przejdź do jego sekcji **Moduły**.
5. Wklej publiczny adres pojedynczego filmu YouTube i wybierz **Dodaj film**.

Obsługiwane są standardowe adresy YouTube, `youtu.be`, osadzenia, Shorts i
transmisje Live. Film musi być publicznie dostępny i zezwalać na osadzanie.

## Ograniczenia Free

- Vimeo i Dailymotion są dostępne w PRO;
- drugi film dla tego samego produktu wymaga PRO;
- film pozostaje na końcu galerii;
- autoplay i wyświetlanie na listach produktów są wyłączone.

Prawidłowy adres Vimeo lub Dailymotion zostanie rozpoznany, ale panel wyjaśni,
że dany serwis wymaga wersji PRO.

## Aktualizacja Free do PRO

Nie odinstalowuj wersji Free. Jej odinstalowanie usuwa zapisane powiązania
filmów.

1. Kup Cool Video PRO.
2. W Menedżerze modułów prześlij otrzymaną paczkę PRO bezpośrednio na
   zainstalowaną wersję Free.
3. Poczekaj na zakończenie aktualizacji.
4. Otwórz konfigurację Cool Video i aktywuj klucz licencyjny.

Dotychczasowe filmy pozostaną zapisane. Po aktywacji będzie można zmienić ich
pozycję, włączyć autoplay, dodać kolejne filmy oraz prezentować je na listach
produktów.

