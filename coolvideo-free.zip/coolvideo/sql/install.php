<?php
/**
 * Database installation.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

$query = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'coolvideo_product_video` (
    `id_coolvideo_product_video` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_product` INT UNSIGNED NOT NULL,
    `video_url` VARCHAR(500) NOT NULL,
    `platform` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT NULL,
    `thumbnail_url` VARCHAR(500) NULL,
    `video_id` VARCHAR(100) NOT NULL,
    `position` INT UNSIGNED NOT NULL DEFAULT 1,
    `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
    `autostart` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
    `show_in_listing` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
    `width` INT UNSIGNED NOT NULL DEFAULT 560,
    `height` INT UNSIGNED NOT NULL DEFAULT 315,
    `date_add` DATETIME NOT NULL,
    `date_upd` DATETIME NOT NULL,
    PRIMARY KEY (`id_coolvideo_product_video`),
    KEY `coolvideo_product_active_position` (`id_product`, `active`, `position`),
    KEY `coolvideo_listing` (`show_in_listing`, `active`, `id_product`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8';

return Db::getInstance()->execute($query);
