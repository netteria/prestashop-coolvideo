<?php
/**
 * Database uninstallation.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

return Db::getInstance()->execute(
    'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'coolvideo_product_video`'
);
