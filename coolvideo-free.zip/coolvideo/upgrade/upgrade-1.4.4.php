<?php
/**
 * Upgrade to version 1.4.4.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_4_4($module)
{
    if (!$module instanceof Coolvideo || !$module->upgradeDatabaseSchema()) {
        return false;
    }

    // Rebuild CCC bundles and page caches so every supported PrestaShop
    // generation immediately references the versioned front assets.
    if (method_exists('Media', 'clearCache')) {
        Media::clearCache();
    }
    if (method_exists('Tools', 'clearAllCache')) {
        Tools::clearAllCache();
    }

    return true;
}
