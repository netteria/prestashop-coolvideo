<?php
/**
 * Upgrade to version 1.3.3.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_3($module)
{
    if (!$module instanceof Coolvideo) {
        return false;
    }

    $table = '`' . _DB_PREFIX_ . 'coolvideo_product_video`';
    $products = Db::getInstance()->executeS(
        'SELECT `id_product` FROM ' . $table . ' GROUP BY `id_product` HAVING MIN(`position`) = 0'
    );

    if (!is_array($products)) {
        return false;
    }

    foreach ($products as $product) {
        if (!Db::getInstance()->execute(
            'UPDATE ' . $table . ' SET `position` = `position` + 1 '
            . 'WHERE `id_product` = ' . (int) $product['id_product']
        )) {
            return false;
        }
    }

    return Db::getInstance()->execute(
        'ALTER TABLE ' . $table . ' MODIFY `position` INT UNSIGNED NOT NULL DEFAULT 1'
    );
}
