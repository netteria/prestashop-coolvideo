<?php
/**
 * Repair Back Office asset registration and clear caches for Free 1.4.9.1.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_4_9_1($module)
{
    if (!$module instanceof Coolvideo || !$module->upgradeDatabaseSchema()) {
        return false;
    }

    if (method_exists('Media', 'clearCache')) {
        Media::clearCache();
    }
    if (method_exists('Tools', 'clearAllCache')) {
        Tools::clearAllCache();
    }

    return true;
}
