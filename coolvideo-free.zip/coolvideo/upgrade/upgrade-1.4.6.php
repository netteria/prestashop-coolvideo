<?php
/**
 * Upgrade to version 1.4.6.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_4_6($module)
{
    if (!$module instanceof Coolvideo || !$module->repairInstallationAfterUpgrade()) {
        return false;
    }

    // Drop compiled asset and hook output caches after the module has been
    // re-enabled and all registrations have been restored.
    if (method_exists('Media', 'clearCache')) {
        Media::clearCache();
    }
    if (method_exists('Tools', 'clearAllCache')) {
        Tools::clearAllCache();
    }

    return true;
}
