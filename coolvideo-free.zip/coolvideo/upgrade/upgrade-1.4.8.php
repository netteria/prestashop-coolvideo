<?php
/**
 * Upgrade to version 1.4.8.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_4_8($module)
{
    if (!$module instanceof Coolvideo) {
        return false;
    }

    return true;
}
