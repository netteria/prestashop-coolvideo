<?php
/**
 * Cool Video Product
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/CoolvideoProductVideo.php';
require_once __DIR__ . '/classes/VideoProvider.php';
require_once __DIR__ . '/classes/CoolvideoFeaturePolicy.php';

class Coolvideo extends Module
{
    public const VERSION = '1.4.9.1';
    public const ADMIN_CONTROLLER = 'AdminCoolvideoProductVideo';

    /** @var bool */
    private $backAssetsRegistered = false;

    public function __construct()
    {
        $this->name = 'coolvideo';
        $this->tab = 'front_office_features';
        $this->version = self::VERSION;
        $this->author = 'Netteria.NET';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = [
            'min' => '1.7.0.0',
            'max' => '9.99.99',
        ];

        parent::__construct();

        if ($this->isFreeEdition()) {
            $this->displayName = $this->l('Cool Video Free: Product Gallery Video');
            $this->description = $this->l('Adds one YouTube video to the end of each product gallery.');
        } else {
            $this->displayName = $this->l('Cool Video: Product Gallery Videos and Autoplay');
            $this->description = $this->l('Adds YouTube, Vimeo and Dailymotion videos to product galleries.');
        }
        $this->confirmUninstall = $this->l('Do you really want to remove the module and all saved product videos?');
    }

    public function isFreeEdition()
    {
        return CoolvideoFeaturePolicy::isFree();
    }

    public function isFeatureAvailable($feature)
    {
        return CoolvideoFeaturePolicy::isFeatureAvailable($feature);
    }

    public function allowsVideoPlatform($platform)
    {
        return CoolvideoFeaturePolicy::allowsPlatform($platform);
    }

    public function getMaxVideosPerProduct()
    {
        return CoolvideoFeaturePolicy::getMaxVideosPerProduct();
    }

    public function getNewVideoPosition($regularPosition)
    {
        return CoolvideoFeaturePolicy::getNewVideoPosition($regularPosition);
    }

    public function getUpgradeUrl()
    {
        return CoolvideoFeaturePolicy::getUpgradeUrl();
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }

        $installed = $this->installDatabase()
            && $this->installAdminTab()
            && $this->registerRequiredHooks();

        if (!$installed) {
            $this->uninstallAdminTab();
            $this->uninstallDatabase();
            parent::uninstall();
        }

        return $installed;
    }

    public function uninstall()
    {
        $tabRemoved = $this->uninstallAdminTab();
        $databaseRemoved = $this->uninstallDatabase();

        return $tabRemoved && $databaseRemoved && parent::uninstall();
    }

    public function hookDisplayBackOfficeHeader()
    {
        $this->registerBackAssets();
    }

    public function hookDisplayAdminProductsExtra($params)
    {
        $this->registerBackAssets();

        $idProduct = $this->getProductIdFromHook($params);
        if ($idProduct <= 0) {
            return '';
        }

        $this->context->smarty->assign([
            'coolvideo_ajax_url' => $this->getAdminAjaxUrl($idProduct),
            'coolvideo_id_product' => $idProduct,
            'coolvideo_videos' => CoolvideoProductVideo::getRowsByProduct($idProduct, false),
            'coolvideo_is_free' => $this->isFreeEdition(),
            'coolvideo_capabilities' => CoolvideoFeaturePolicy::getCapabilities(),
            'coolvideo_upgrade_url' => $this->getUpgradeUrl(),
            'coolvideo_upgrade_image_url' => $this->_path . 'views/img/coolvideo-pro-upgrade.png',
            'coolvideo_back_css_url' => $this->_path . 'views/css/back.css?v=' . rawurlencode($this->version),
            'coolvideo_back_js_url' => $this->_path . 'views/js/back.js?v=' . rawurlencode($this->version),
        ]);

        return $this->display(__FILE__, 'views/templates/admin/product-videos-form.tpl');
    }

    public function hookDisplayHeader()
    {
        $this->registerFrontAssets();

        $idProduct = (int) Tools::getValue('id_product');
        $videos = [];
        if ($idProduct > 0) {
            $videos = $this->getStorefrontRows($idProduct);
        }

        $ajaxUrl = '';
        if ($this->isFeatureAvailable(CoolvideoFeaturePolicy::FEATURE_PRODUCT_LISTING)) {
            $ajaxUrl = $this->context->link->getModuleLink(
                $this->name,
                'ajax',
                ['ajax' => 1, 'cv' => $this->version],
                true
            );
        }

        Media::addJsDef([
            'coolvideoConfig' => [
                'prestashopVersion' => defined('_PS_VERSION_') ? (string) _PS_VERSION_ : '',
                'productId' => $idProduct,
                'videos' => $videos,
                'ajaxUrl' => $ajaxUrl,
                'modalTitle' => $this->l('Product video'),
                'closeLabel' => $this->l('Close video'),
                'playLabel' => $this->l('Play video'),
            ],
        ]);
    }

    private function registerBackAssets()
    {
        if ($this->backAssetsRegistered) {
            return;
        }
        if (!isset($this->context->controller) || !is_object($this->context->controller)) {
            return;
        }

        $controller = $this->context->controller;
        $this->backAssetsRegistered = true;
        if (method_exists($controller, 'registerStylesheet') && method_exists($controller, 'registerJavascript')) {
            $controller->registerStylesheet(
                'module-' . $this->name . '-admin',
                'modules/' . $this->name . '/views/css/back.css',
                [
                    'media' => 'all',
                    'priority' => 200,
                    'version' => $this->version,
                ]
            );
            $controller->registerJavascript(
                'module-' . $this->name . '-admin',
                'modules/' . $this->name . '/views/js/back.js',
                [
                    'position' => 'bottom',
                    'priority' => 200,
                    'version' => $this->version,
                ]
            );

            return;
        }

        $controller->addCSS($this->_path . 'views/css/back.css');
        $controller->addJS($this->_path . 'views/js/back.js');
    }

    private function registerFrontAssets()
    {
        $controller = $this->context->controller;
        if (method_exists($controller, 'registerStylesheet') && method_exists($controller, 'registerJavascript')) {
            $controller->registerStylesheet(
                'module-' . $this->name . '-front',
                'modules/' . $this->name . '/views/css/front-1.4.4.css',
                [
                    'media' => 'all',
                    'priority' => 200,
                    'version' => $this->version,
                ]
            );
            $controller->registerJavascript(
                'module-' . $this->name . '-front',
                'modules/' . $this->name . '/views/js/front-1.4.4.js',
                [
                    'position' => 'bottom',
                    'priority' => 200,
                    'version' => $this->version,
                ]
            );

            return;
        }

        // Compatibility fallback for legacy front controllers.
        $controller->addCSS($this->_path . 'views/css/front-1.4.4.css');
        $controller->addJS($this->_path . 'views/js/front-1.4.4.js');
    }

    public function hookDisplayProductExtraContent($params)
    {
        $idProduct = $this->getProductIdFromHook($params);
        if ($idProduct <= 0) {
            return [];
        }

        $videos = $this->getStorefrontRows($idProduct);
        if (empty($videos)) {
            return [];
        }

        $this->context->smarty->assign('coolvideo_videos', $videos);
        $content = $this->display(__FILE__, 'views/templates/front/product-videos.tpl');

        return [
            (new PrestaShop\PrestaShop\Core\Product\ProductExtraContent())
                ->setTitle($this->l('Videos'))
                ->setContent($content),
        ];
    }

    public function hookDisplayAfterProductThumbs($params)
    {
        return $this->renderProductGalleryMount($params);
    }

    public function hookDisplayFooterProduct($params)
    {
        return $this->renderProductGalleryMount($params);
    }

    public function hookActionObjectProductDeleteAfter($params)
    {
        if (isset($params['object']) && $params['object'] instanceof Product) {
            return CoolvideoProductVideo::deleteByProduct((int) $params['object']->id);
        }

        return true;
    }

    public function upgradeDatabaseSchema()
    {
        if (!$this->installDatabase()) {
            return false;
        }

        $columns = [
            'autostart' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `active`',
            'show_in_listing' => 'TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 AFTER `autostart`',
        ];

        foreach ($columns as $column => $definition) {
            if (!$this->databaseColumnExists($column)) {
                $query = 'ALTER TABLE `' . _DB_PREFIX_ . 'coolvideo_product_video` '
                    . 'ADD `' . bqSQL($column) . '` ' . $definition;
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }

        $indexes = [
            'coolvideo_product_active_position' => '(`id_product`, `active`, `position`)',
            'coolvideo_listing' => '(`show_in_listing`, `active`, `id_product`)',
        ];
        foreach ($indexes as $index => $definition) {
            if (!$this->databaseIndexExists($index)) {
                $query = 'ALTER TABLE `' . _DB_PREFIX_ . 'coolvideo_product_video` '
                    . 'ADD INDEX `' . bqSQL($index) . '` ' . $definition;
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }

        return $this->installAdminTab() && $this->registerRequiredHooks();
    }

    /**
     * Restore a complete installed module state after an interrupted upgrade.
     *
     * PrestaShop can keep the new files and database version after an upgrade
     * exception while the module remains disabled in the current shop context.
     * In that state neither displayAdminProductsExtra nor displayHeader runs,
     * so the product "Modules" tab and all front-office assets disappear.
     *
     * This method is intentionally used only by the recovery upgrade. It does
     * not make regular requests silently enable a module disabled by a merchant.
     *
     * @return bool
     */
    public function repairInstallationAfterUpgrade()
    {
        if (!$this->upgradeDatabaseSchema()) {
            return false;
        }

        if (!$this->active) {
            if (!$this->enable()) {
                return false;
            }

            // Module::enable() updates module_shop but the current instance is
            // not reconstructed during runUpgradeModule() on PrestaShop 1.7.
            $this->active = true;
        }

        return true;
    }

    /**
     * Register every hook required by the back and front office.
     *
     * Do not use a boolean short-circuit chain here: if one legacy hook cannot
     * be restored, all remaining registrations still need to be attempted so
     * a retry can recover cleanly on PrestaShop 1.7, 8 and 9.
     *
     * @return bool
     */
    private function registerRequiredHooks()
    {
        $hooks = [
            'displayBackOfficeHeader',
            'displayAdminProductsExtra',
            'displayHeader',
            'displayProductExtraContent',
            'displayAfterProductThumbs',
            'displayFooterProduct',
            'actionObjectProductDeleteAfter',
        ];
        $registered = true;

        foreach ($hooks as $hook) {
            if (!$this->registerHook($hook)) {
                $registered = false;
            }
        }

        return $registered;
    }

    private function installDatabase()
    {
        return (bool) include $this->local_path . 'sql/install.php';
    }

    private function uninstallDatabase()
    {
        return (bool) include $this->local_path . 'sql/uninstall.php';
    }

    private function installAdminTab()
    {
        if ((int) Tab::getIdFromClassName(self::ADMIN_CONTROLLER) > 0) {
            return true;
        }

        $tab = new Tab();
        $tab->active = true;
        $tab->class_name = self::ADMIN_CONTROLLER;
        $tab->id_parent = -1;
        $tab->module = $this->name;

        foreach (Language::getLanguages(false) as $language) {
            $tab->name[(int) $language['id_lang']] = $this->l('Product videos');
        }

        return (bool) $tab->add();
    }

    private function uninstallAdminTab()
    {
        $idTab = (int) Tab::getIdFromClassName(self::ADMIN_CONTROLLER);
        if ($idTab <= 0) {
            return true;
        }

        return (bool) (new Tab($idTab))->delete();
    }

    private function getAdminAjaxUrl($idProduct)
    {
        return $this->context->link->getAdminLink(self::ADMIN_CONTROLLER)
            . '&ajax=1&id_product=' . (int) $idProduct;
    }

    private function renderProductGalleryMount($params)
    {
        $idProduct = $this->getProductIdFromHook($params);
        if ($idProduct <= 0) {
            return '';
        }

        $videos = $this->getStorefrontRows($idProduct);
        if (empty($videos)) {
            return '';
        }

        $videosJson = self::encodeJson($videos);

        $this->context->smarty->assign([
            'coolvideo_mount_product_id' => $idProduct,
            'coolvideo_mount_videos_json' => $videosJson,
        ]);

        return $this->display(__FILE__, 'views/templates/front/gallery-mount.tpl');
    }

    private static function encodeJson($value)
    {
        // Tools::jsonEncode() was removed in PrestaShop 9. Native json_encode()
        // is available on every PHP version supported by PrestaShop 1.7+.
        $json = json_encode($value);

        return is_string($json) ? $json : '[]';
    }

    private function getStorefrontRows($idProduct)
    {
        return CoolvideoFeaturePolicy::filterStorefrontRows(
            CoolvideoProductVideo::getRowsByProduct((int) $idProduct, true)
        );
    }

    private function getProductIdFromHook($params)
    {
        if (isset($params['id_product'])) {
            return (int) $params['id_product'];
        }

        if (isset($params['id'])) {
            return (int) $params['id'];
        }

        if (isset($params['product'])) {
            if ($params['product'] instanceof Product) {
                return (int) $params['product']->id;
            }
            if (is_array($params['product']) && isset($params['product']['id_product'])) {
                return (int) $params['product']['id_product'];
            }
            if ($params['product'] instanceof ArrayAccess && isset($params['product']['id_product'])) {
                return (int) $params['product']['id_product'];
            }
            if (is_object($params['product']) && isset($params['product']->id_product)) {
                return (int) $params['product']->id_product;
            }
        }

        return (int) Tools::getValue('id_product');
    }

    private function databaseColumnExists($column)
    {
        $query = 'SHOW COLUMNS FROM `' . _DB_PREFIX_ . 'coolvideo_product_video` '
            . "LIKE '" . pSQL($column) . "'";

        $rows = Db::getInstance()->executeS($query);

        return is_array($rows) && !empty($rows);
    }

    private function databaseIndexExists($index)
    {
        $query = 'SHOW INDEX FROM `' . _DB_PREFIX_ . 'coolvideo_product_video` '
            . "WHERE `Key_name` = '" . pSQL($index) . "'";

        $rows = Db::getInstance()->executeS($query);

        return is_array($rows) && !empty($rows);
    }
}
