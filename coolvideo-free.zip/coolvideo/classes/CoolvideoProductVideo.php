<?php
/**
 * Product video persistence model.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CoolvideoProductVideo extends ObjectModel
{
    private static $rowsCache = [];

    public $id_coolvideo_product_video;
    public $id_product;
    public $video_url;
    public $platform;
    public $title;
    public $description;
    public $thumbnail_url;
    public $video_id;
    public $position = 1;
    public $active = 1;
    public $autostart = 0;
    public $show_in_listing = 0;
    public $width = 560;
    public $height = 315;
    public $date_add;
    public $date_upd;

    public static $definition = [
        'table' => 'coolvideo_product_video',
        'primary' => 'id_coolvideo_product_video',
        'fields' => [
            'id_product' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'video_url' => [
                'type' => self::TYPE_STRING,
                'validate' => 'isString',
                'required' => true,
                'size' => 500,
            ],
            'platform' => [
                'type' => self::TYPE_STRING,
                'validate' => 'isGenericName',
                'required' => true,
                'size' => 50,
            ],
            'title' => ['type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'size' => 255],
            'description' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'thumbnail_url' => [
                'type' => self::TYPE_STRING,
                'validate' => 'isString',
                'size' => 500,
            ],
            'video_id' => [
                'type' => self::TYPE_STRING,
                'validate' => 'isGenericName',
                'required' => true,
                'size' => 100,
            ],
            'position' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'active' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'autostart' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'show_in_listing' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
            'width' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'height' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
        ],
    ];

    public static function getByProduct($idProduct, $active = true)
    {
        $rows = self::getRowsByProduct($idProduct, $active);
        $videos = [];

        foreach ($rows as $row) {
            $videos[] = new self((int) $row['id_coolvideo_product_video']);
        }

        return $videos;
    }

    public static function getRowsByProduct($idProduct, $active = true)
    {
        $cacheKey = (int) $idProduct . ':' . (int) $active;
        if (isset(self::$rowsCache[$cacheKey])) {
            return self::$rowsCache[$cacheKey];
        }

        $query = 'SELECT * FROM `' . _DB_PREFIX_ . 'coolvideo_product_video` '
            . 'WHERE `id_product` = ' . (int) $idProduct;
        if ($active) {
            $query .= ' AND `active` = 1';
        }
        $query .= ' ORDER BY `position` ASC, `id_coolvideo_product_video` ASC';

        $rows = Db::getInstance()->executeS($query);
        if (!is_array($rows)) {
            return [];
        }

        foreach ($rows as &$row) {
            $row = self::normalizeRow($row);
        }
        unset($row);

        self::$rowsCache[$cacheKey] = $rows;

        return self::$rowsCache[$cacheKey];
    }

    public static function getListingRows(array $productIds)
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $productIds))));
        $ids = array_slice($ids, 0, 100);
        if (empty($ids)) {
            return [];
        }

        $query = 'SELECT * FROM `' . _DB_PREFIX_ . 'coolvideo_product_video` '
            . 'WHERE `id_product` IN (' . implode(',', $ids) . ') '
            . 'AND `active` = 1 AND `show_in_listing` = 1 AND `position` = 1 '
            . 'ORDER BY `id_product` ASC, `position` ASC, `id_coolvideo_product_video` ASC';
        $rows = Db::getInstance()->executeS($query);
        $result = [];

        if (!is_array($rows)) {
            return $result;
        }

        foreach ($rows as $row) {
            $idProduct = (int) $row['id_product'];
            if (!isset($result[$idProduct])) {
                $result[$idProduct] = self::normalizeRow($row);
            }
        }

        return $result;
    }

    public static function deleteByProduct($idProduct)
    {
        return Db::getInstance()->delete(
            'coolvideo_product_video',
            '`id_product` = ' . (int) $idProduct
        );
    }

    public static function getNextPosition($idProduct)
    {
        $query = 'SELECT COALESCE(MAX(`position`), 0) + 1 FROM `'
            . _DB_PREFIX_ . 'coolvideo_product_video` WHERE `id_product` = ' . (int) $idProduct;

        return (int) Db::getInstance()->getValue($query);
    }

    public static function countByProduct($idProduct)
    {
        $query = 'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'coolvideo_product_video` '
            . 'WHERE `id_product` = ' . (int) $idProduct;

        return (int) Db::getInstance()->getValue($query);
    }

    public static function updatePosition($idVideo, $position, $idProduct = 0)
    {
        $where = '`id_coolvideo_product_video` = ' . (int) $idVideo;
        if ((int) $idProduct > 0) {
            $where .= ' AND `id_product` = ' . (int) $idProduct;
        }

        return Db::getInstance()->update(
            'coolvideo_product_video',
            ['position' => max(1, (int) $position)],
            $where
        );
    }

    private static function normalizeRow($row)
    {
        $integerFields = [
            'id_coolvideo_product_video', 'id_product', 'position', 'active',
            'autostart', 'show_in_listing', 'width', 'height',
        ];
        foreach ($integerFields as $field) {
            if (isset($row[$field])) {
                $row[$field] = (int) $row[$field];
            }
        }

        $row['embed_url'] = CoolvideoVideoProvider::getEmbedUrl(
            isset($row['platform']) ? $row['platform'] : '',
            isset($row['video_id']) ? $row['video_id'] : '',
            false
        );

        return $row;
    }
}
