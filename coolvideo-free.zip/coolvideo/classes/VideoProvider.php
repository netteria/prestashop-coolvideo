<?php
/**
 * Video URL parser and embed URL builder.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CoolvideoVideoProvider
{
    public const PLATFORM_YOUTUBE = 'youtube';
    public const PLATFORM_VIMEO = 'vimeo';
    public const PLATFORM_DAILYMOTION = 'dailymotion';

    public static function extractVideoData($url)
    {
        if (!is_string($url)) {
            return false;
        }

        $url = trim($url);
        if ($url === '' || strlen($url) > 500 || !filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $parts = parse_url($url);
        if (!is_array($parts) || empty($parts['host'])) {
            return false;
        }

        $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
        if ($scheme !== 'http' && $scheme !== 'https') {
            return false;
        }

        $host = strtolower($parts['host']);
        $host = preg_replace('/^www\./', '', $host);
        $path = isset($parts['path']) ? trim($parts['path'], '/') : '';
        $videoId = '';

        if ($host === 'youtu.be') {
            $segments = explode('/', $path);
            $videoId = isset($segments[0]) ? $segments[0] : '';

            return self::buildData(self::PLATFORM_YOUTUBE, $videoId, $url);
        }

        if ($host === 'youtube.com' || $host === 'm.youtube.com' || $host === 'music.youtube.com') {
            if ($path === 'watch') {
                $query = [];
                parse_str(isset($parts['query']) ? $parts['query'] : '', $query);
                $videoId = isset($query['v']) ? $query['v'] : '';
            } elseif (preg_match('~^(?:embed|shorts|live)/([A-Za-z0-9_-]+)~', $path, $matches)) {
                $videoId = $matches[1];
            }

            return self::buildData(self::PLATFORM_YOUTUBE, $videoId, $url);
        }

        if ($host === 'vimeo.com' || $host === 'player.vimeo.com') {
            if (preg_match('~(?:^|video/)([0-9]+)(?:/|$)~', $path, $matches)) {
                $videoId = $matches[1];
            }

            return self::buildData(self::PLATFORM_VIMEO, $videoId, $url);
        }

        if ($host === 'dai.ly') {
            $segments = explode('/', $path);
            $videoId = isset($segments[0]) ? $segments[0] : '';

            return self::buildData(self::PLATFORM_DAILYMOTION, $videoId, $url);
        }

        if ($host === 'dailymotion.com' || $host === 'geo.dailymotion.com') {
            if (preg_match('~^(?:embed/)?video/([A-Za-z0-9]+)(?:[_/-]|$)~', $path, $matches)) {
                $videoId = $matches[1];
            }

            return self::buildData(self::PLATFORM_DAILYMOTION, $videoId, $url);
        }

        return false;
    }

    public static function isValidUrl($url)
    {
        return self::extractVideoData($url) !== false;
    }

    public static function getEmbedUrl($platform, $videoId, $autostart)
    {
        if (!self::isValidVideoId($platform, $videoId)) {
            return '';
        }

        if ($platform === self::PLATFORM_YOUTUBE) {
            $url = 'https://www.youtube-nocookie.com/embed/' . rawurlencode($videoId) . '?rel=0';

            return $autostart ? $url . '&autoplay=1&mute=1' : $url;
        }

        if ($platform === self::PLATFORM_VIMEO) {
            $url = 'https://player.vimeo.com/video/' . rawurlencode($videoId);

            return $autostart ? $url . '?autoplay=1&muted=1' : $url;
        }

        if ($platform === self::PLATFORM_DAILYMOTION) {
            $url = 'https://www.dailymotion.com/embed/video/' . rawurlencode($videoId);

            return $autostart ? $url . '?autoplay=1&mute=1' : $url;
        }

        return '';
    }

    public static function getEmbedHtml($videoData, $width = 560, $height = 315, $autostart = false)
    {
        if (!is_array($videoData) || empty($videoData['platform'])) {
            return '';
        }

        $videoId = isset($videoData['video_id']) ? $videoData['video_id'] : '';
        if ($videoId === '' && !empty($videoData['embed_url'])) {
            $parsedData = self::extractVideoData($videoData['embed_url']);
            $videoId = $parsedData !== false ? $parsedData['video_id'] : '';
        }
        $embedUrl = self::getEmbedUrl($videoData['platform'], $videoId, $autostart);
        if ($embedUrl === '') {
            return '';
        }

        $width = max(1, min(4096, (int) $width));
        $height = max(1, min(4096, (int) $height));

        return '<iframe width="' . $width . '" height="' . $height . '" src="'
            . htmlspecialchars($embedUrl, ENT_QUOTES, 'UTF-8')
            . '" title="Video player" frameborder="0" loading="lazy" '
            . 'allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>';
    }

    public static function getThumbnailUrl($videoData)
    {
        if (!is_array($videoData) || empty($videoData['platform']) || empty($videoData['video_id'])) {
            return '';
        }

        $platform = $videoData['platform'];
        $videoId = $videoData['video_id'];
        if (!self::isValidVideoId($platform, $videoId)) {
            return '';
        }

        if ($platform === self::PLATFORM_YOUTUBE) {
            return 'https://img.youtube.com/vi/' . rawurlencode($videoId) . '/hqdefault.jpg';
        }

        if ($platform === self::PLATFORM_VIMEO) {
            return 'https://vumbnail.com/' . rawurlencode($videoId) . '.jpg';
        }

        if ($platform === self::PLATFORM_DAILYMOTION) {
            return 'https://www.dailymotion.com/thumbnail/video/' . rawurlencode($videoId);
        }

        return '';
    }

    private static function buildData($platform, $videoId, $originalUrl)
    {
        if (!self::isValidVideoId($platform, $videoId)) {
            return false;
        }

        $data = [
            'platform' => $platform,
            'video_id' => $videoId,
            'video_url' => $originalUrl,
            'title' => ucfirst($platform) . ' - ' . $videoId,
            'description' => '',
            'embed_url' => self::getEmbedUrl($platform, $videoId, false),
            'width' => 560,
            'height' => 315,
        ];
        $data['thumbnail_url'] = self::getThumbnailUrl($data);

        return $data;
    }

    private static function isValidVideoId($platform, $videoId)
    {
        if (!is_string($videoId) && !is_numeric($videoId)) {
            return false;
        }

        $videoId = (string) $videoId;
        if ($platform === self::PLATFORM_YOUTUBE) {
            return (bool) preg_match('/^[A-Za-z0-9_-]{6,20}$/', $videoId);
        }
        if ($platform === self::PLATFORM_VIMEO) {
            return (bool) preg_match('/^[0-9]{1,20}$/', $videoId);
        }
        if ($platform === self::PLATFORM_DAILYMOTION) {
            return (bool) preg_match('/^[A-Za-z0-9]{4,20}$/', $videoId);
        }

        return false;
    }
}
