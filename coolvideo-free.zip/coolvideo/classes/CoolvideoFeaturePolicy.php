<?php
/**
 * Distribution-level feature policy for Cool Video.
 *
 * The canonical Marketplace source is PRO by default. The Free build replaces
 * only the EDITION and UPGRADE_URL constants in its temporary staging copy.
 * This keeps a single implementation of the feature gates without leaking a
 * sales URL into the Marketplace archive.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CoolvideoFeaturePolicy
{
    public const EDITION_PRO = 'pro';
    public const EDITION_FREE = 'free';

    /** Build marker replaced only inside the staged Free archive. */
    public const EDITION = self::EDITION_FREE;

    /** Kept empty in Marketplace/PRO sources; injected by the direct Free build. */
    public const UPGRADE_URL = 'https://prestaexpert.pl/strona-glowna/24-modul-wideo-do-galerii-produktu-prestashop-cool-video.html?utm_source=coolvideo&utm_medium=free-module&utm_campaign=free-to-pro';

    public const FEATURE_MULTIPLE_VIDEOS = 'multiple_videos';
    public const FEATURE_CUSTOM_POSITION = 'custom_position';
    public const FEATURE_AUTOPLAY = 'autoplay';
    public const FEATURE_PRODUCT_LISTING = 'product_listing';

    public const FREE_MAX_VIDEOS_PER_PRODUCT = 1;
    public const FREE_GALLERY_POSITION = 10000;

    public static function isFree()
    {
        return self::EDITION === self::EDITION_FREE;
    }

    public static function isFeatureAvailable($feature)
    {
        if (!self::isFree()) {
            return true;
        }

        return !in_array((string) $feature, [
            self::FEATURE_MULTIPLE_VIDEOS,
            self::FEATURE_CUSTOM_POSITION,
            self::FEATURE_AUTOPLAY,
            self::FEATURE_PRODUCT_LISTING,
        ], true);
    }

    public static function allowsPlatform($platform)
    {
        return !self::isFree() || (string) $platform === CoolvideoVideoProvider::PLATFORM_YOUTUBE;
    }

    public static function getMaxVideosPerProduct()
    {
        return self::isFree() ? self::FREE_MAX_VIDEOS_PER_PRODUCT : 0;
    }

    public static function getNewVideoPosition($regularPosition)
    {
        return self::isFree() ? self::FREE_GALLERY_POSITION : max(1, (int) $regularPosition);
    }

    public static function getCapabilities()
    {
        return [
            'multiple_videos' => self::isFeatureAvailable(self::FEATURE_MULTIPLE_VIDEOS),
            'custom_position' => self::isFeatureAvailable(self::FEATURE_CUSTOM_POSITION),
            'autoplay' => self::isFeatureAvailable(self::FEATURE_AUTOPLAY),
            'product_listing' => self::isFeatureAvailable(self::FEATURE_PRODUCT_LISTING),
            'vimeo' => !self::isFree(),
            'dailymotion' => !self::isFree(),
        ];
    }

    /**
     * Enforce the Free storefront contract even if rows were imported or
     * edited outside the product form. No saved data is deleted.
     */
    public static function filterStorefrontRows(array $rows)
    {
        if (!self::isFree()) {
            return $rows;
        }

        foreach ($rows as $row) {
            if (empty($row['active']) || !self::allowsPlatform(isset($row['platform']) ? $row['platform'] : '')) {
                continue;
            }

            $row['position'] = self::FREE_GALLERY_POSITION;
            $row['autostart'] = 0;
            $row['show_in_listing'] = 0;

            return [$row];
        }

        return [];
    }

    public static function getUpgradeUrl()
    {
        return self::isFree() ? self::UPGRADE_URL : '';
    }
}
