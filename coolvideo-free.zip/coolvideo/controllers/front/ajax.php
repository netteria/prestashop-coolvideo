<?php
/**
 * Read-only public endpoint used on product listing pages.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CoolvideoAjaxModuleFrontController extends ModuleFrontController
{
    public $ajax = true;

    public function initContent()
    {
        parent::initContent();

        if (Tools::getValue('action') !== 'GetListingVideos') {
            $this->respond(false, [], 400);
        }

        if (method_exists($this->module, 'isFeatureAvailable')
            && !$this->module->isFeatureAvailable(CoolvideoFeaturePolicy::FEATURE_PRODUCT_LISTING)
        ) {
            $this->respond(true, []);
        }

        $rawIds = Tools::getValue('product_ids');
        if (is_string($rawIds) && strlen($rawIds) > 2000) {
            $this->respond(false, [], 400);
        }
        if (is_array($rawIds)) {
            $productIds = $rawIds;
        } else {
            $productIds = explode(',', (string) $rawIds);
        }

        $productIds = array_slice(array_values(array_unique(array_filter(array_map('intval', $productIds)))), 0, 100);
        if (empty($productIds)) {
            $this->respond(true, []);
        }

        $this->respond(true, CoolvideoProductVideo::getListingRows($productIds));
    }

    private function respond($success, $videos, $statusCode = 200)
    {
        http_response_code((int) $statusCode);
        header('Content-Type: application/json; charset=utf-8');
        // Listing visibility depends on the current gallery position. Do not
        // reuse an answer after a merchant moves a video in the back office.
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');

        exit(json_encode([
            'success' => (bool) $success,
            'videos' => $videos,
        ]));
    }
}
