<?php
/**
 * Secured Back Office AJAX controller for product videos.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminCoolvideoProductVideoController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        if (!Tools::getValue('ajax')) {
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminProducts'));
        }
    }

    public function ajaxProcessAdd()
    {
        $this->assertWriteAccess();

        $idProduct = $this->getValidProductId();
        $url = trim((string) Tools::getValue('url'));
        $videoData = CoolvideoVideoProvider::extractVideoData($url);

        if ($videoData === false) {
            $this->respond(false, $this->module->l('Invalid or unsupported video URL.'), 422);
        }

        if (!$this->module->allowsVideoPlatform($videoData['platform'])) {
            $this->respondUpgradeRequired(
                $this->module->l('This video service is available in Cool Video PRO. Cool Video Free supports YouTube.')
            );
        }

        $maxVideos = (int) $this->module->getMaxVideosPerProduct();
        if ($maxVideos > 0 && CoolvideoProductVideo::countByProduct($idProduct) >= $maxVideos) {
            $this->respondUpgradeRequired(
                $this->module->l('Cool Video Free allows one video per product. Add multiple videos with Cool Video PRO.')
            );
        }

        $video = new CoolvideoProductVideo();
        $video->id_product = $idProduct;
        $video->video_url = $url;
        $video->platform = $videoData['platform'];
        $video->video_id = $videoData['video_id'];
        $video->thumbnail_url = $videoData['thumbnail_url'];
        $video->title = $videoData['title'];
        $video->description = '';
        $video->position = $this->module->getNewVideoPosition(
            CoolvideoProductVideo::getNextPosition($idProduct)
        );
        $video->active = 1;
        $video->autostart = 0;
        $video->show_in_listing = 0;
        $video->width = 560;
        $video->height = 315;

        $validation = $video->validateFields(false, true);
        if ($validation !== true || !$video->add()) {
            $this->respond(false, $this->module->l('The video could not be saved.'), 500);
        }

        $this->respond(true, $this->module->l('Video added.'), 200, [
            'video' => CoolvideoProductVideo::getRowsByProduct($idProduct, false),
        ]);
    }

    public function ajaxProcessDelete()
    {
        $this->assertWriteAccess();
        $video = $this->getOwnedVideo();

        if (!$video->delete()) {
            $this->respond(false, $this->module->l('The video could not be deleted.'), 500);
        }

        $this->respond(true, $this->module->l('Video deleted.'));
    }

    public function ajaxProcessToggle()
    {
        $this->toggleBooleanField('active');
    }

    public function ajaxProcessToggleAutostart()
    {
        $this->toggleBooleanField('autostart');
    }

    public function ajaxProcessToggleListing()
    {
        $this->toggleBooleanField('show_in_listing');
    }

    public function ajaxProcessUpdatePositions()
    {
        $this->assertWriteAccess();
        $this->assertFeatureAvailable(
            CoolvideoFeaturePolicy::FEATURE_CUSTOM_POSITION,
            $this->module->l('Custom gallery positions are available in Cool Video PRO. Free videos stay at the end of the gallery.')
        );
        $idProduct = $this->getValidProductId();
        $videoIds = Tools::getValue('video');

        if (!is_array($videoIds)) {
            $this->respond(false, $this->module->l('Invalid position data.'), 422);
        }

        $saved = true;
        foreach (array_values($videoIds) as $position => $idVideo) {
            if (!CoolvideoProductVideo::updatePosition((int) $idVideo, (int) $position + 1, $idProduct)) {
                $saved = false;
            }
        }

        if (!$saved) {
            $this->respond(false, $this->module->l('Some positions could not be saved.'), 500);
        }

        $this->respond(true, $this->module->l('Positions saved.'));
    }

    public function ajaxProcessUpdatePosition()
    {
        $this->assertWriteAccess();
        $this->assertFeatureAvailable(
            CoolvideoFeaturePolicy::FEATURE_CUSTOM_POSITION,
            $this->module->l('Custom gallery positions are available in Cool Video PRO. Free videos stay at the end of the gallery.')
        );
        $video = $this->getOwnedVideo();
        $position = (int) Tools::getValue('position');

        if ($position < 1 || $position > 10000) {
            $this->respond(false, $this->module->l('Invalid gallery position.'), 422);
        }

        if (!CoolvideoProductVideo::updatePosition((int) $video->id, $position, (int) $video->id_product)) {
            $this->respond(false, $this->module->l('The gallery position could not be saved.'), 500);
        }

        $this->respond(true, $this->module->l('Gallery position saved.'));
    }

    private function toggleBooleanField($field)
    {
        $this->assertWriteAccess();

        if ($field === 'autostart') {
            $this->assertFeatureAvailable(
                CoolvideoFeaturePolicy::FEATURE_AUTOPLAY,
                $this->module->l('Muted autoplay is available in Cool Video PRO.')
            );
        }
        if ($field === 'show_in_listing') {
            $this->assertFeatureAvailable(
                CoolvideoFeaturePolicy::FEATURE_PRODUCT_LISTING,
                $this->module->l('Product-listing videos are available in Cool Video PRO.')
            );
        }

        $video = $this->getOwnedVideo();
        $video->{$field} = (int) (bool) Tools::getValue($field);

        if (!$video->update()) {
            $this->respond(false, $this->module->l('The video could not be updated.'), 500);
        }

        $this->respond(true, $this->module->l('Video updated.'));
    }

    private function getOwnedVideo()
    {
        $idProduct = $this->getValidProductId();
        $idVideo = (int) Tools::getValue('id_video');
        $video = new CoolvideoProductVideo($idVideo);

        if (!Validate::isLoadedObject($video) || (int) $video->id_product !== $idProduct) {
            $this->respond(false, $this->module->l('Video not found.'), 404);
        }

        return $video;
    }

    private function getValidProductId()
    {
        $idProduct = (int) Tools::getValue('id_product');
        $product = new Product($idProduct);

        if ($idProduct <= 0 || !Validate::isLoadedObject($product)) {
            $this->respond(false, $this->module->l('Product not found.'), 404);
        }

        return $idProduct;
    }

    private function assertWriteAccess()
    {
        if (strtoupper(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '') !== 'POST') {
            $this->respond(false, $this->module->l('Only POST requests are allowed.'), 405);
        }

        if (!$this->access('edit')) {
            $this->respond(false, $this->module->l('You do not have permission to edit product videos.'), 403);
        }
    }

    private function assertFeatureAvailable($feature, $message)
    {
        if (!$this->module->isFeatureAvailable($feature)) {
            $this->respondUpgradeRequired($message);
        }
    }

    private function respondUpgradeRequired($message)
    {
        $this->respond(false, $message, 403, [
            'code' => 'upgrade_required',
            'upgrade_url' => $this->module->getUpgradeUrl(),
        ]);
    }

    private function respond($success, $message, $statusCode = 200, $extra = [])
    {
        http_response_code((int) $statusCode);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate');

        $payload = array_merge([
            'success' => (bool) $success,
            'message' => (string) $message,
        ], $extra);

        exit(json_encode($payload));
    }
}
