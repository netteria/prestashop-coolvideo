/**
 * Cool Video Product
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

/* Compatibility loader for cached PrestaShop 1.7 theme references. */
(function () {
  'use strict';

  if (window.coolvideoVersionedAssetLoading) {
    return;
  }

  var scripts = document.getElementsByTagName('script');
  var currentScript = document.currentScript || scripts[scripts.length - 1];
  var source = currentScript && currentScript.src
    ? currentScript.src.replace(/front\.js(?:\?.*)?$/, 'front-1.4.4.js')
    : '';
  if (!source || source === (currentScript && currentScript.src)) {
    return;
  }

  window.coolvideoVersionedAssetLoading = true;
  var script = document.createElement('script');
  script.src = source;
  script.async = false;
  document.head.appendChild(script);
}());
