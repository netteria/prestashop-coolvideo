/**
 * Cool Video Product
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

/* Coolvideo 1.4.4 front adapter. */
/* eslint-disable no-var, object-shorthand */
(function () {
  'use strict';

  var config = window.coolvideoConfig || {};
  var modal = null;
  var lastTrigger = null;
  var reinjectionTimer = null;
  var listingInjectionTimer = null;
  var listingRequestPending = false;
  var listingObserverStarted = false;
  var listingVideosCache = {};
  var listingLoadedProductIds = {};
  var listingProductSelector =
    '.js-product-miniature[data-id-product], article.product-miniature[data-id-product], ' +
    '[data-product-id].product-miniature, [data-product-id][class*="product-card"]';
  var prestashopGeneration = getPrestaShopGeneration();

  function getPrestaShopGeneration () {
    var version = String(config.prestashopVersion || '');
    var major = parseInt(version.split('.')[0], 10);

    if (/^1\.7(?:\.|$)/.test(version)) {
      return '17';
    }
    if (major >= 9) {
      return '9';
    }
    if (major === 8) {
      return '8';
    }
    return 'legacy';
  }

  document.documentElement.classList.add('coolvideo-ps-' + prestashopGeneration);

  function createElement (tag, className, text) {
    var element = document.createElement(tag);
    if (className) {
      element.className = className;
    }
    if (text) {
      element.textContent = text;
    }
    return element;
  }

  function validVideo (video) {
    return video &&
      /^(youtube|vimeo|dailymotion)$/.test(String(video.platform || '')) &&
      /^[A-Za-z0-9_-]{1,100}$/.test(String(video.video_id || ''));
  }

  function validListingVideo (video) {
    // A product card represents the first gallery item. The listing flag
    // permits replacement, but it must never override gallery ordering.
    return validVideo(video) && Math.max(1, parseInt(video.position, 10) || 1) === 1;
  }

  function videoMarker (video) {
    return String(video.id_coolvideo_product_video || video.id || video.video_id);
  }

  function getVideos () {
    var videos = Array.isArray(config.videos) ? config.videos.slice() : [];
    var mounts;

    if (videos.length === 0) {
      mounts = document.querySelectorAll('[data-coolvideo-mount][data-coolvideo-videos]');
      Array.prototype.some.call(mounts, function (mount) {
        try {
          videos = JSON.parse(mount.getAttribute('data-coolvideo-videos') || '[]');
        } catch (error) {
          videos = [];
        }
        return Array.isArray(videos) && videos.length > 0;
      });
    }

    return videos.filter(validVideo).sort(function (left, right) {
      var positionDifference = Number(left.position || 0) - Number(right.position || 0);
      if (positionDifference !== 0) {
        return positionDifference;
      }
      return Number(left.id_coolvideo_product_video || 0) - Number(right.id_coolvideo_product_video || 0);
    });
  }

  function findVideo (videos, marker) {
    return videos.filter(function (video) {
      return videoMarker(video) === String(marker);
    })[0] || null;
  }

  function buildEmbedUrl (video, forceAutoplay, suppressConfiguredAutoplay) {
    if (!validVideo(video)) {
      return '';
    }

    var id = encodeURIComponent(video.video_id);
    var autoplay = forceAutoplay === true ||
      (suppressConfiguredAutoplay !== true && Number(video.autostart) === 1);
    if (video.platform === 'youtube') {
      return 'https://www.youtube-nocookie.com/embed/' + id + '?rel=0' + (autoplay ? '&autoplay=1&mute=1' : '');
    }
    if (video.platform === 'vimeo') {
      return 'https://player.vimeo.com/video/' + id + (autoplay ? '?autoplay=1&muted=1' : '');
    }
    return 'https://www.dailymotion.com/embed/video/' + id + (autoplay ? '?autoplay=1&mute=1' : '');
  }

  function ensureModal () {
    if (modal) {
      return modal;
    }

    modal = createElement('div', 'coolvideo-modal');
    modal.hidden = true;
    modal.setAttribute('data-coolvideo', 'modal');
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', config.modalTitle || 'Product video');

    var panel = createElement('div', 'coolvideo-modal-panel');
    var closeButton = createElement('button', 'coolvideo-modal-close', '\u00d7');
    closeButton.type = 'button';
    closeButton.setAttribute('aria-label', config.closeLabel || 'Close video');
    var frameWrap = createElement('div', 'coolvideo-modal-frame');

    closeButton.addEventListener('click', closeModal);
    modal.addEventListener('click', function (event) {
      if (event.target === modal) {
        closeModal();
      }
    });

    panel.appendChild(closeButton);
    panel.appendChild(frameWrap);
    modal.appendChild(panel);
    document.body.appendChild(modal);

    return modal;
  }

  function openModal (video, trigger) {
    var embedUrl = buildEmbedUrl(video, true, false);
    if (!embedUrl) {
      return;
    }

    var dialog = ensureModal();
    var frameWrap = dialog.querySelector('.coolvideo-modal-frame');
    var iframe = document.createElement('iframe');
    iframe.src = embedUrl;
    iframe.title = video.title || config.modalTitle || 'Product video';
    iframe.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    iframe.allowFullscreen = true;
    iframe.setAttribute('loading', 'eager');

    frameWrap.textContent = '';
    frameWrap.appendChild(iframe);
    lastTrigger = trigger || null;
    dialog.hidden = false;
    document.body.classList.add('coolvideo-modal-open');
    dialog.querySelector('.coolvideo-modal-close').focus();
  }

  function closeModal () {
    if (!modal || modal.hidden) {
      return;
    }
    modal.hidden = true;
    modal.querySelector('.coolvideo-modal-frame').textContent = '';
    document.body.classList.remove('coolvideo-modal-open');
    if (lastTrigger && document.documentElement.contains(lastTrigger)) {
      lastTrigger.focus();
    }
  }

  function createVideoImage (video, className) {
    var image = document.createElement('img');
    image.src = video.thumbnail_url || '';
    image.alt = video.title || '';
    image.loading = 'lazy';
    image.className = className || 'coolvideo-gallery-thumbnail';
    return image;
  }

  function appendPlayIcon (element) {
    var icon = createElement('span', 'coolvideo-play-icon', '\u25b6');
    icon.setAttribute('aria-hidden', 'true');
    element.appendChild(icon);
  }

  function createVideoButton (video, className, onActivate) {
    var button = createElement('button', className || 'coolvideo-gallery-button');
    button.type = 'button';
    button.setAttribute('aria-label', (config.playLabel || 'Play video') + ': ' + (video.title || video.platform));
    button.setAttribute('data-coolvideo-video-id', videoMarker(video));
    button.appendChild(createVideoImage(video, className === 'coolvideo-gallery-button' ? 'coolvideo-gallery-thumbnail' : ''));
    appendPlayIcon(button);
    button.addEventListener('click', function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof onActivate === 'function') {
        onActivate(video, button);
        return;
      }
      openModal(video, button);
    });
    return button;
  }

  function createPlayer (video, className, forceAutoplay, suppressConfiguredAutoplay) {
    var embedUrl = buildEmbedUrl(video, forceAutoplay === true, suppressConfiguredAutoplay === true);
    if (!embedUrl) {
      return null;
    }

    var wrapper = createElement('div', className);
    var iframe = document.createElement('iframe');
    iframe.src = embedUrl;
    iframe.title = video.title || config.modalTitle || 'Product video';
    iframe.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    iframe.allowFullscreen = true;
    iframe.setAttribute('data-coolvideo-player', videoMarker(video));
    wrapper.appendChild(iframe);
    return wrapper;
  }

  function findContainers (selectors) {
    var containers = [];
    selectors.forEach(function (selector) {
      Array.prototype.forEach.call(document.querySelectorAll(selector), function (element) {
        var container = /^(UL|OL)$/.test(element.tagName) ? element : element.querySelector('ul, ol');
        if (container && containers.indexOf(container) === -1) {
          containers.push(container);
        }
      });
    });
    return containers;
  }

  function getClassicMainContainers () {
    return findContainers([
      '.js-qv-product-images',
      '[data-product-images]',
      '.product-thumbnails',
      '[data-product-thumbnails]'
    ]).filter(function (container) {
      return !container.closest('.js-product-images-modal, #product-modal, .product__images');
    });
  }

  function getClassicModalContainers () {
    return findContainers([
      '.js-modal-product-images',
      '.js-product-images-modal .product-images',
      '#product-modal .product-images'
    ]).filter(function (container) {
      return !container.closest('.product__images');
    });
  }

  function setSelectedThumbnail (container, button) {
    if (!container) {
      return;
    }
    Array.prototype.forEach.call(container.querySelectorAll('.coolvideo-gallery-button-selected'), function (thumbnail) {
      thumbnail.classList.remove('coolvideo-gallery-button-selected');
    });
    button.classList.add('coolvideo-gallery-button-selected');
  }

  function clearClassicCoverVideo () {
    var wrapper = document.querySelector('.coolvideo-product-cover-video');
    if (wrapper && wrapper.parentNode) {
      wrapper.parentNode.removeChild(wrapper);
    }
    Array.prototype.forEach.call(document.querySelectorAll('.product-cover .js-qv-product-cover, .product-cover .layer'), function (element) {
      element.hidden = false;
    });
    Array.prototype.forEach.call(document.querySelectorAll('.coolvideo-main-gallery-strip .coolvideo-gallery-button-selected'), function (button) {
      button.classList.remove('coolvideo-gallery-button-selected');
    });
    Array.prototype.forEach.call(document.querySelectorAll('.coolvideo-main-gallery-strip[data-coolvideo-cover-video]'), function (container) {
      container.removeAttribute('data-coolvideo-cover-video');
    });
  }

  function showClassicCoverVideo (video, button, forceAutoplay) {
    var cover = document.querySelector('.product-cover');
    var image = cover ? cover.querySelector('.js-qv-product-cover, img') : null;
    var player = createPlayer(video, 'coolvideo-product-cover-video', forceAutoplay !== false, false);
    if (!cover || !image || !player) {
      openModal(video, button);
      return;
    }

    clearClassicCoverVideo();
    image.hidden = true;
    Array.prototype.forEach.call(cover.querySelectorAll('.layer'), function (layer) {
      layer.hidden = true;
    });
    cover.appendChild(player);
    setSelectedThumbnail(button.closest('ul, ol'), button);
  }

  function clearClassicModalVideo (modalElement) {
    if (!modalElement) {
      return;
    }
    var wrapper = modalElement.querySelector('.coolvideo-native-modal-video');
    if (wrapper && wrapper.parentNode) {
      wrapper.parentNode.removeChild(wrapper);
    }
    Array.prototype.forEach.call(modalElement.querySelectorAll('.js-modal-product-cover, .product-cover-modal'), function (image) {
      image.hidden = false;
    });
    Array.prototype.forEach.call(modalElement.querySelectorAll('.coolvideo-gallery-button-selected'), function (button) {
      button.classList.remove('coolvideo-gallery-button-selected');
    });
  }

  function showClassicModalVideo (video, button) {
    var modalElement = button.closest('.js-product-images-modal, #product-modal');
    var image = modalElement ? modalElement.querySelector('.js-modal-product-cover, .product-cover-modal') : null;
    var player = createPlayer(video, 'coolvideo-native-modal-video', true, false);
    if (!modalElement || !image || !player || !image.parentNode) {
      openModal(video, button);
      return;
    }

    modalElement.classList.add('coolvideo-classic-native-modal');
    modalElement.setAttribute('data-coolvideo-ps-generation', prestashopGeneration);
    clearClassicModalVideo(modalElement);
    image.hidden = true;
    image.parentNode.insertBefore(player, image.nextSibling);
    setSelectedThumbnail(button.closest('ul, ol'), button);
  }

  function getClassicReferenceThumbnail (container, modalContext) {
    var selector = modalContext
      ? 'img.js-modal-thumb:not(.coolvideo-gallery-thumbnail)'
      : 'img.js-thumb:not(.coolvideo-gallery-thumbnail)';
    return container.querySelector(selector) ||
      container.querySelector('li:not(.coolvideo-gallery-item) img:not(.coolvideo-gallery-thumbnail)');
  }

  function synchronizeClassicThumbnailSizes (container, modalContext) {
    var reference = getClassicReferenceThumbnail(container, modalContext);
    if (!reference) {
      return;
    }
    var box = reference.getBoundingClientRect();
    var width = Math.round(box.width || reference.clientWidth || 0);
    var height = Math.round(box.height || reference.clientHeight || 0);
    if (width <= 0 || height <= 0) {
      return;
    }

    Array.prototype.forEach.call(container.querySelectorAll('.coolvideo-gallery-button'), function (button) {
      button.style.width = width + 'px';
      button.style.height = height + 'px';
    });
  }

  function insertClassicVideos (container, videos, modalContext) {
    container.classList.add(modalContext ? 'coolvideo-modal-gallery-strip' : 'coolvideo-main-gallery-strip');
    container.setAttribute('data-coolvideo-adapter', 'classic');

    var imageItems = Array.prototype.filter.call(container.children, function (item) {
      return !item.hasAttribute('data-coolvideo-video-id');
    });
    var orderedItems = imageItems.slice();

    videos.forEach(function (video) {
      var marker = videoMarker(video);
      var item = container.querySelector('[data-coolvideo-video-id="' + marker + '"]');
      if (!item) {
        item = createElement('li', 'thumb-container coolvideo-gallery-item');
        item.setAttribute('data-coolvideo-video-id', marker);
        item.appendChild(createVideoButton(
          video,
          'coolvideo-gallery-button',
          modalContext ? showClassicModalVideo : showClassicCoverVideo
        ));
      }

      var position = Math.max(1, parseInt(video.position, 10) || 1);
      orderedItems.splice(Math.min(position - 1, orderedItems.length), 0, item);
    });

    orderedItems.forEach(function (item) {
      container.appendChild(item);
    });
    synchronizeClassicThumbnailSizes(container, modalContext);
    return orderedItems;
  }

  function displayFirstClassicVideo (container, videos) {
    var firstItem = container ? container.firstElementChild : null;
    if (!firstItem || !firstItem.hasAttribute('data-coolvideo-video-id')) {
      return;
    }

    var marker = firstItem.getAttribute('data-coolvideo-video-id');
    if (container.getAttribute('data-coolvideo-cover-video') === marker &&
      document.querySelector('.coolvideo-product-cover-video')) {
      return;
    }

    var video = findVideo(videos, marker);
    var button = firstItem.querySelector('.coolvideo-gallery-button');
    if (video && button) {
      container.setAttribute('data-coolvideo-cover-video', marker);
      showClassicCoverVideo(video, button, false);
    }
  }

  function injectClassic (videos, selectFirstItem) {
    var mainContainers = getClassicMainContainers();
    var modalContainers = getClassicModalContainers();

    if (mainContainers.length === 0) {
      return false;
    }

    document.documentElement.classList.add('coolvideo-adapter-classic');
    mainContainers.forEach(function (container) {
      insertClassicVideos(container, videos, false);
    });
    if (selectFirstItem === true) {
      displayFirstClassicVideo(mainContainers[0], videos);
    }
    modalContainers.forEach(function (container) {
      var modalElement = container.closest('.js-product-images-modal, #product-modal');
      if (modalElement) {
        modalElement.classList.add('coolvideo-classic-native-modal');
        modalElement.setAttribute('data-coolvideo-ps-generation', prestashopGeneration);
      }
      insertClassicVideos(container, videos, true);
    });
    return true;
  }

  function getHummingbirdRoots () {
    return Array.prototype.slice.call(document.querySelectorAll('.product__images.js-images-container, .product__images'))
      .filter(function (root) {
        return root.querySelector('.js-product-carousel, .product__carousel');
      });
  }

  function ensureHummingbirdThumbnailList (root, carousel) {
    var list = root.querySelector('.product__thumbnails-list');
    if (list) {
      return list;
    }

    var wrapper = createElement('div', 'product__thumbnails coolvideo-hummingbird-thumbnails');
    list = createElement('ul', 'product__thumbnails-list');
    wrapper.appendChild(list);
    carousel.parentNode.insertBefore(wrapper, carousel.nextSibling);
    return list;
  }

  function createHummingbirdSlide (video, modalContext) {
    var slideClass = modalContext
      ? 'carousel-item coolvideo-hummingbird-modal-slide'
      : 'carousel-item coolvideo-hummingbird-slide';
    var playerClass = modalContext
      ? 'coolvideo-hummingbird-player coolvideo-hummingbird-modal-player'
      : 'coolvideo-hummingbird-player';
    var slide = createElement('div', slideClass);
    var player = createPlayer(video, playerClass, false, true);
    slide.setAttribute('data-coolvideo-video-id', videoMarker(video));
    if (player) {
      slide.appendChild(player);
    }
    return slide;
  }

  function createHummingbirdThumbnail (video, modalContext) {
    var className = 'product__thumbnail focus-ring js-thumb-container coolvideo-hummingbird-thumbnail';
    if (modalContext) {
      className += ' coolvideo-hummingbird-modal-thumbnail';
    }
    var button = createElement('button', className);
    button.type = 'button';
    button.setAttribute('data-coolvideo-video-id', videoMarker(video));
    button.setAttribute('aria-label', (config.playLabel || 'Play video') + ': ' + (video.title || video.platform));
    button.appendChild(createVideoImage(
      video,
      'product__thumbnail-image outline outline--rounded img-fluid coolvideo-gallery-thumbnail'
    ));
    appendPlayIcon(button);
    return button;
  }

  function createHummingbirdModalImageThumbnail (sourceThumbnail, slide, imageIndex) {
    var button = createElement(
      'button',
      'product__thumbnail focus-ring js-thumb-container coolvideo-hummingbird-modal-thumbnail'
    );
    var source = sourceThumbnail
      ? sourceThumbnail.querySelector('picture, img')
      : slide.querySelector('picture, img');

    button.type = 'button';
    button.setAttribute('data-coolvideo-image-index', String(imageIndex));
    button.setAttribute('aria-label', 'Product image ' + String(imageIndex + 1));
    if (source) {
      var thumbnailContent = source.cloneNode(true);
      var image = thumbnailContent.tagName === 'IMG'
        ? thumbnailContent
        : thumbnailContent.querySelector('img');
      if (image) {
        image.className = 'product__thumbnail-image outline outline--rounded img-fluid';
        image.removeAttribute('sizes');
        image.removeAttribute('data-full-size-image-url');
      }
      button.appendChild(thumbnailContent);
    }

    return button;
  }

  function ensureHummingbirdCarouselControls (carousel, itemCount) {
    if (!carousel || itemCount <= 1) {
      return;
    }

    ['prev', 'next'].forEach(function (direction) {
      var control = carousel.querySelector('.carousel-control-' + direction);
      if (!control) {
        control = createElement('button', 'carousel-control-' + direction + ' outline outline--rounded');
        control.type = 'button';
        control.appendChild(createElement('span', 'carousel-control-' + direction + '-icon'));
        var label = createElement('span', 'visually-hidden', direction === 'prev' ? 'Previous media' : 'Next media');
        control.appendChild(label);
        carousel.appendChild(control);
      }
      control.setAttribute('data-bs-target', '#' + carousel.id);
      control.setAttribute('data-bs-slide', direction);
    });
  }

  function activateHummingbirdIndex (carousel, thumbnailList, index) {
    var slides = Array.prototype.slice.call(carousel.querySelectorAll('.carousel-inner > .carousel-item'));
    var thumbnails = Array.prototype.slice.call(thumbnailList.children);

    slides.forEach(function (slide, slideIndex) {
      slide.classList.toggle('active', slideIndex === index);
    });
    thumbnails.forEach(function (thumbnail, thumbnailIndex) {
      thumbnail.classList.toggle('active', thumbnailIndex === index);
      if (thumbnailIndex === index) {
        thumbnail.setAttribute('aria-current', 'true');
      } else {
        thumbnail.removeAttribute('aria-current');
      }
    });
    refreshHummingbirdPlayers(carousel, getVideos());
  }

  function refreshHummingbirdPlayers (carousel, videos) {
    var activeSlide = carousel.querySelector('.carousel-inner > .carousel-item.active');
    Array.prototype.forEach.call(carousel.querySelectorAll('[data-coolvideo-video-id] iframe[data-coolvideo-player]'), function (iframe) {
      var slide = iframe.closest('.carousel-item');
      var video = findVideo(videos, slide ? slide.getAttribute('data-coolvideo-video-id') : '');
      if (!video) {
        return;
      }
      var autoplay = slide === activeSlide && Number(video.autostart) === 1;
      var desiredUrl = buildEmbedUrl(video, autoplay, true);
      if (iframe.getAttribute('src') !== desiredUrl) {
        iframe.setAttribute('src', desiredUrl);
      }
    });
  }

  function bindHummingbirdCarousel (carousel, thumbnailList) {
    if (carousel.getAttribute('data-coolvideo-bound') === '1') {
      return;
    }
    carousel.setAttribute('data-coolvideo-bound', '1');
    carousel.addEventListener('slid.bs.carousel', function () {
      refreshHummingbirdPlayers(carousel, getVideos());
    });
    thumbnailList.addEventListener('click', function (event) {
      var thumbnail = event.target.closest ? event.target.closest('.coolvideo-hummingbird-thumbnail') : null;
      if (!thumbnail) {
        return;
      }
      var index = parseInt(thumbnail.getAttribute('data-bs-slide-to'), 10);
      window.setTimeout(function () {
        var active = carousel.querySelector('.carousel-inner > .carousel-item.active');
        if (!active || active !== carousel.querySelectorAll('.carousel-inner > .carousel-item')[index]) {
          activateHummingbirdIndex(carousel, thumbnailList, index);
        }
        refreshHummingbirdPlayers(carousel, getVideos());
        var selectedSlide = carousel.querySelectorAll('.carousel-inner > .carousel-item')[index];
        var selectedVideo = selectedSlide
          ? findVideo(getVideos(), selectedSlide.getAttribute('data-coolvideo-video-id'))
          : null;
        var selectedIframe = selectedSlide ? selectedSlide.querySelector('iframe[data-coolvideo-player]') : null;
        if (selectedVideo && selectedIframe) {
          selectedIframe.setAttribute('src', buildEmbedUrl(selectedVideo, true, true));
        }
      }, 0);
    });
  }

  function getHummingbirdActiveIndex (carousel) {
    if (!carousel) {
      return -1;
    }
    var slides = Array.prototype.slice.call(carousel.querySelectorAll('.carousel-inner > .carousel-item'));
    return slides.indexOf(carousel.querySelector('.carousel-inner > .carousel-item.active'));
  }

  function forceHummingbirdVideoAtIndex (carousel, index) {
    var slide = carousel
      ? carousel.querySelectorAll('.carousel-inner > .carousel-item')[index]
      : null;
    var video = slide
      ? findVideo(getVideos(), slide.getAttribute('data-coolvideo-video-id'))
      : null;
    var iframe = slide ? slide.querySelector('iframe[data-coolvideo-player]') : null;
    if (video && iframe) {
      iframe.setAttribute('src', buildEmbedUrl(video, true, true));
    }
  }

  function stopHummingbirdPlayers (carousel) {
    if (!carousel) {
      return;
    }
    Array.prototype.forEach.call(carousel.querySelectorAll('iframe[data-coolvideo-player]'), function (iframe) {
      var slide = iframe.closest('.carousel-item');
      var video = findVideo(getVideos(), slide ? slide.getAttribute('data-coolvideo-video-id') : '');
      if (video) {
        iframe.setAttribute('src', buildEmbedUrl(video, false, true));
      }
    });
  }

  function syncHummingbirdModalToMain (root, forceAutoplay) {
    var mainCarousel = root ? root.querySelector('.js-product-carousel, .product__carousel') : null;
    var modal = root ? root.querySelector('.js-product-images-modal, #product-modal') : null;
    var modalCarousel = modal
      ? modal.querySelector('.js-product-images-modal-carousel, .product-images-modal__carousel')
      : null;
    var modalThumbnails = modal ? modal.querySelector('.coolvideo-hummingbird-modal-thumbnail-list') : null;
    var index = getHummingbirdActiveIndex(mainCarousel);

    if (!modalCarousel || !modalThumbnails || index < 0) {
      return;
    }

    activateHummingbirdIndex(modalCarousel, modalThumbnails, index);
    if (forceAutoplay === true) {
      forceHummingbirdVideoAtIndex(modalCarousel, index);
    }
  }

  function bindHummingbirdModalCarousel (root, modal, carousel, thumbnailList) {
    if (thumbnailList.getAttribute('data-coolvideo-bound') !== '1') {
      thumbnailList.setAttribute('data-coolvideo-bound', '1');
      thumbnailList.addEventListener('click', function (event) {
        var thumbnail = event.target.closest
          ? event.target.closest('.coolvideo-hummingbird-modal-thumbnail')
          : null;
        if (!thumbnail) {
          return;
        }
        var index = parseInt(thumbnail.getAttribute('data-bs-slide-to'), 10);
        window.setTimeout(function () {
          activateHummingbirdIndex(carousel, thumbnailList, index);
          forceHummingbirdVideoAtIndex(carousel, index);
        }, 0);
      });
    }

    if (carousel.getAttribute('data-coolvideo-modal-bound') !== '1') {
      carousel.setAttribute('data-coolvideo-modal-bound', '1');
      carousel.addEventListener('slid.bs.carousel', function () {
        var index = getHummingbirdActiveIndex(carousel);
        if (index >= 0) {
          activateHummingbirdIndex(carousel, thumbnailList, index);
        }
      });
    }

    if (modal.getAttribute('data-coolvideo-modal-events-bound') !== '1') {
      modal.setAttribute('data-coolvideo-modal-events-bound', '1');
      modal.addEventListener('shown.bs.modal', function () {
        syncHummingbirdModalToMain(root, true);
      });
      modal.addEventListener('hidden.bs.modal', function () {
        stopHummingbirdPlayers(carousel);
      });
    }
  }

  function insertHummingbirdModalVideos (root, videos, mainThumbnailList) {
    var modal = root.querySelector('.js-product-images-modal, #product-modal');
    var carousel = modal
      ? modal.querySelector('.js-product-images-modal-carousel, .product-images-modal__carousel')
      : null;
    var inner = carousel ? carousel.querySelector('.carousel-inner') : null;
    var body = modal ? modal.querySelector('.product-images-modal__body, .modal-body') : null;
    if (!modal || !carousel || !inner || !body) {
      return false;
    }

    if (!carousel.id) {
      carousel.id = 'coolvideo-product-modal-carousel-' + String(config.productId || 'current');
    }

    var mainCarousel = root.querySelector('.js-product-carousel, .product__carousel');
    var selectedIndex = Math.max(0, getHummingbirdActiveIndex(mainCarousel));
    var imageSlides = Array.prototype.filter.call(inner.children, function (slide) {
      return !slide.hasAttribute('data-coolvideo-video-id');
    });
    var imageThumbnails = Array.prototype.filter.call(mainThumbnailList.children, function (thumbnail) {
      return !thumbnail.hasAttribute('data-coolvideo-video-id');
    }).sort(function (left, right) {
      return Number(left.getAttribute('data-bs-slide-to') || 0) - Number(right.getAttribute('data-bs-slide-to') || 0);
    });
    var media = imageSlides.map(function (slide, index) {
      slide.setAttribute('data-coolvideo-image-index', String(index));
      return {
        slide: slide,
        sourceThumbnail: imageThumbnails[index] || null,
        imageIndex: index,
        video: null
      };
    });

    videos.forEach(function (video) {
      var marker = videoMarker(video);
      var slide = inner.querySelector('[data-coolvideo-video-id="' + marker + '"]') ||
        createHummingbirdSlide(video, true);
      var position = Math.max(1, parseInt(video.position, 10) || 1);
      media.splice(Math.min(position - 1, media.length), 0, {
        slide: slide,
        sourceThumbnail: null,
        imageIndex: -1,
        video: video
      });
    });
    selectedIndex = Math.min(selectedIndex, Math.max(0, media.length - 1));

    var thumbnailWrapper = modal.querySelector('.coolvideo-hummingbird-modal-thumbnails');
    if (!thumbnailWrapper) {
      thumbnailWrapper = createElement(
        'div',
        'product__thumbnails coolvideo-hummingbird-modal-thumbnails'
      );
      body.appendChild(thumbnailWrapper);
    }
    var thumbnailList = thumbnailWrapper.querySelector('.coolvideo-hummingbird-modal-thumbnail-list');
    if (!thumbnailList) {
      thumbnailList = createElement(
        'ul',
        'product__thumbnails-list coolvideo-hummingbird-modal-thumbnail-list'
      );
      thumbnailWrapper.appendChild(thumbnailList);
    }
    thumbnailList.textContent = '';

    media.forEach(function (item, index) {
      var thumbnail = item.video
        ? createHummingbirdThumbnail(item.video, true)
        : createHummingbirdModalImageThumbnail(item.sourceThumbnail, item.slide, item.imageIndex);
      var isActive = index === selectedIndex;

      inner.appendChild(item.slide);
      thumbnail.setAttribute('data-bs-target', '#' + carousel.id);
      thumbnail.setAttribute('data-bs-slide-to', String(index));
      thumbnailList.appendChild(thumbnail);
      item.slide.classList.toggle('active', isActive);
      thumbnail.classList.toggle('active', isActive);
      if (isActive) {
        thumbnail.setAttribute('aria-current', 'true');
      }
    });

    ensureHummingbirdCarouselControls(carousel, media.length);
    modal.classList.add('coolvideo-hummingbird-native-modal');
    modal.setAttribute('data-coolvideo-ps-generation', prestashopGeneration);
    bindHummingbirdModalCarousel(root, modal, carousel, thumbnailList);
    refreshHummingbirdPlayers(carousel, videos);
    return true;
  }

  function insertHummingbirdVideos (root, videos, selectFirstItem) {
    var carousel = root.querySelector('.js-product-carousel, .product__carousel');
    var inner = carousel ? carousel.querySelector('.carousel-inner') : null;
    if (!carousel || !inner) {
      return false;
    }

    if (!carousel.id) {
      carousel.id = 'coolvideo-product-carousel-' + String(config.productId || 'current');
    }

    var thumbnailList = ensureHummingbirdThumbnailList(root, carousel);
    var activeSlide = inner.querySelector('.carousel-item.active');
    var imageSlides = Array.prototype.filter.call(inner.children, function (slide) {
      return !slide.hasAttribute('data-coolvideo-video-id');
    });
    var imageThumbnails = Array.prototype.filter.call(thumbnailList.children, function (thumbnail) {
      return !thumbnail.hasAttribute('data-coolvideo-video-id');
    }).sort(function (left, right) {
      return Number(left.getAttribute('data-bs-slide-to') || 0) - Number(right.getAttribute('data-bs-slide-to') || 0);
    });
    var media = imageSlides.map(function (slide, index) {
      return { slide: slide, thumbnail: imageThumbnails[index] || null, video: null };
    });

    videos.forEach(function (video) {
      var marker = videoMarker(video);
      var slide = inner.querySelector('[data-coolvideo-video-id="' + marker + '"]') || createHummingbirdSlide(video);
      var thumbnail = thumbnailList.querySelector('[data-coolvideo-video-id="' + marker + '"]') ||
        createHummingbirdThumbnail(video);
      var position = Math.max(1, parseInt(video.position, 10) || 1);
      media.splice(Math.min(position - 1, media.length), 0, {
        slide: slide,
        thumbnail: thumbnail,
        video: video
      });
    });

    media.forEach(function (item, index) {
      inner.appendChild(item.slide);
      if (item.thumbnail) {
        item.thumbnail.setAttribute('data-bs-target', '#' + carousel.id);
        item.thumbnail.setAttribute('data-bs-slide-to', String(index));
        thumbnailList.appendChild(item.thumbnail);
      }
      var isActive = selectFirstItem === true ? index === 0 : item.slide === activeSlide;
      item.slide.classList.toggle('active', isActive);
      if (item.thumbnail) {
        item.thumbnail.classList.toggle('active', isActive);
        if (isActive) {
          item.thumbnail.setAttribute('aria-current', 'true');
        } else {
          item.thumbnail.removeAttribute('aria-current');
        }
      }
    });

    if (selectFirstItem !== true && !inner.querySelector('.carousel-item.active') && media[0]) {
      media[0].slide.classList.add('active');
      if (media[0].thumbnail) {
        media[0].thumbnail.classList.add('active');
        media[0].thumbnail.setAttribute('aria-current', 'true');
      }
    }

    root.setAttribute('data-coolvideo-adapter', 'hummingbird');
    ensureHummingbirdCarouselControls(carousel, media.length);
    bindHummingbirdCarousel(carousel, thumbnailList);
    refreshHummingbirdPlayers(carousel, videos);
    insertHummingbirdModalVideos(root, videos, thumbnailList);
    return true;
  }

  function injectHummingbird (videos, selectFirstItem) {
    var roots = getHummingbirdRoots();
    var injected = false;
    roots.forEach(function (root) {
      injected = insertHummingbirdVideos(root, videos, selectFirstItem) || injected;
    });
    if (injected) {
      document.documentElement.classList.add('coolvideo-adapter-hummingbird');
    }
    return injected;
  }

  function findGenericMount () {
    var mounts = Array.prototype.slice.call(document.querySelectorAll('[data-coolvideo-mount]'));
    var anchor;
    if (mounts.length > 0) {
      return mounts[0];
    }

    anchor = document.querySelector(
      '[data-product-gallery], .product-gallery, .product-images, .product-cover, .product__images, [class*="product-gallery"]'
    );
    if (!anchor || !anchor.parentNode) {
      return null;
    }

    var mount = createElement('div', 'coolvideo-theme-mount');
    mount.setAttribute('data-coolvideo-mount', 'generated');
    anchor.parentNode.insertBefore(mount, anchor.nextSibling);
    return mount;
  }

  function hideUnusedMounts (activeMount) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-coolvideo-mount]'), function (mount) {
      if (mount !== activeMount) {
        mount.hidden = true;
      }
    });
  }

  function injectGenericFallback (videos) {
    var mount = findGenericMount();
    if (!mount) {
      return false;
    }

    var gallery = mount.querySelector('.coolvideo-fallback-gallery');
    if (!gallery) {
      gallery = createElement('div', 'coolvideo-fallback-gallery');
      gallery.setAttribute('role', 'group');
      gallery.setAttribute('aria-label', config.modalTitle || 'Product videos');
      mount.appendChild(gallery);
    }
    gallery.textContent = '';
    videos.forEach(function (video) {
      gallery.appendChild(createVideoButton(video, 'coolvideo-gallery-button'));
    });
    mount.hidden = false;
    mount.setAttribute('data-coolvideo-adapter', 'generic');
    hideUnusedMounts(mount);
    document.documentElement.classList.add('coolvideo-adapter-generic');
    return true;
  }

  function hideFallbackMounts () {
    Array.prototype.forEach.call(document.querySelectorAll('[data-coolvideo-mount]'), function (mount) {
      mount.hidden = true;
    });
  }

  function injectProductGallery (selectFirstItem) {
    var videos = getVideos();
    if (!Number(config.productId) && videos.length === 0) {
      return;
    }
    if (videos.length === 0) {
      return;
    }

    if (injectHummingbird(videos, selectFirstItem)) {
      hideFallbackMounts();
      return;
    }
    if (injectClassic(videos, selectFirstItem)) {
      hideFallbackMounts();
      return;
    }
    injectGenericFallback(videos);
  }

  function getListingProducts () {
    return Array.prototype.slice.call(document.querySelectorAll(listingProductSelector));
  }

  function getListingImageTarget (product) {
    var dedicatedContainer = product.querySelector(
      '.product-miniature__image-container, .product-image-block, .thumbnail-top, .product-image'
    );
    if (dedicatedContainer) {
      return { element: dedicatedContainer, mode: 'cover' };
    }

    var imageLink = product.querySelector('.product-thumbnail, a.thumbnail');
    if (imageLink && imageLink.parentNode) {
      return { element: imageLink.parentNode, mode: 'legacy-corner' };
    }

    var fallbackContainer = product.querySelector('.thumbnail-container');
    return fallbackContainer
      ? { element: fallbackContainer, mode: 'legacy-corner' }
      : null;
  }

  function injectListingVideo (product, video) {
    if (!validListingVideo(video) || product.querySelector('[data-coolvideo-listing]')) {
      return;
    }

    var listingTarget = getListingImageTarget(product);
    if (!listingTarget) {
      return;
    }

    var button = createVideoButton(video, 'coolvideo-listing-button');
    button.setAttribute('data-coolvideo-listing', '1');
    button.setAttribute('data-coolvideo-listing-mode', listingTarget.mode);
    button.setAttribute('data-coolvideo-ps-generation', prestashopGeneration);
    var target = listingTarget.element;
    target.classList.add('coolvideo-listing-target');
    target.setAttribute('data-coolvideo-listing-target', listingTarget.mode);
    target.appendChild(button);
  }

  function applyListingVideos () {
    getListingProducts().forEach(function (product) {
      var id = product.getAttribute('data-id-product') || product.getAttribute('data-product-id');
      if (listingVideosCache[id]) {
        injectListingVideo(product, listingVideosCache[id]);
      }
    });
  }

  function injectListingVideos () {
    if (Number(config.productId) || !config.ajaxUrl || !window.fetch || listingRequestPending) {
      return;
    }

    var products = getListingProducts();
    var ids = products.map(function (product) {
      return Number(product.getAttribute('data-id-product') || product.getAttribute('data-product-id'));
    }).filter(function (id) {
      return id > 0;
    }).filter(function (id, index, productIds) {
      return productIds.indexOf(id) === index;
    }).slice(0, 100);

    applyListingVideos();

    var unloadedIds = ids.filter(function (id) {
      return !listingLoadedProductIds[id];
    });

    if (unloadedIds.length === 0) {
      return;
    }

    var separator = config.ajaxUrl.indexOf('?') === -1 ? '?' : '&';
    var url = config.ajaxUrl + separator + 'action=GetListingVideos&product_ids=' +
      encodeURIComponent(unloadedIds.join(','));
    listingRequestPending = true;
    window.fetch(url, { credentials: 'same-origin' })
      .then(function (response) {
        return response.json();
      })
      .then(function (payload) {
        if (!payload.success || !payload.videos) {
          listingRequestPending = false;
          return;
        }

        unloadedIds.forEach(function (id) {
          listingLoadedProductIds[id] = true;
        });
        Object.keys(payload.videos).forEach(function (id) {
          if (validListingVideo(payload.videos[id])) {
            listingVideosCache[id] = payload.videos[id];
          }
        });
        listingRequestPending = false;
        applyListingVideos();
        scheduleListingInjection(0);
      })
      .catch(function () {
        listingRequestPending = false;
        // Product cards remain unchanged when the optional listing request fails.
      });
  }

  function scheduleListingInjection (delay) {
    if (listingInjectionTimer) {
      window.clearTimeout(listingInjectionTimer);
    }
    listingInjectionTimer = window.setTimeout(function () {
      listingInjectionTimer = null;
      injectListingVideos();
    }, typeof delay === 'number' ? delay : 50);
  }

  function observeListingChanges () {
    if (listingObserverStarted || !window.MutationObserver || !document.body) {
      return;
    }

    listingObserverStarted = true;
    var observer = new window.MutationObserver(function (mutations) {
      var productCardChanged = mutations.some(function (mutation) {
        var target = mutation.target;
        if (target && target.nodeType === 1 && target.closest && target.closest(listingProductSelector)) {
          return true;
        }
        return Array.prototype.some.call(mutation.addedNodes, function (node) {
          if (!node || (node.nodeType !== 1 && node.nodeType !== 11)) {
            return false;
          }
          return (node.matches && node.matches(listingProductSelector)) ||
            (node.querySelector && node.querySelector(listingProductSelector));
        });
      });

      if (productCardChanged) {
        scheduleListingInjection(50);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function scheduleGalleryInjection (selectFirstItem) {
    if (reinjectionTimer) {
      window.clearTimeout(reinjectionTimer);
    }
    reinjectionTimer = window.setTimeout(function () {
      reinjectionTimer = null;
      injectProductGallery(selectFirstItem === true);
    }, 30);
  }

  function initialise () {
    injectProductGallery(true);
    injectListingVideos();
    observeListingChanges();
    window.setTimeout(function () {
      injectProductGallery(false);
      injectListingVideos();
    }, 250);
  }

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closeModal();
    }
  });

  document.addEventListener('click', function (event) {
    var hummingbirdModalTrigger = event.target.closest
      ? event.target.closest('[data-bs-toggle="modal"][data-bs-target="#product-modal"]')
      : null;
    if (hummingbirdModalTrigger) {
      var hummingbirdRoot = hummingbirdModalTrigger.closest('.product__images');
      if (hummingbirdRoot) {
        syncHummingbirdModalToMain(hummingbirdRoot, true);
        window.setTimeout(function () {
          syncHummingbirdModalToMain(hummingbirdRoot, true);
        }, 0);
      }
    }

    var productImage = event.target.closest ? event.target.closest('.js-thumb') : null;
    if (productImage && !productImage.classList.contains('coolvideo-gallery-thumbnail') &&
      !productImage.closest('.product__images')) {
      clearClassicCoverVideo();
    }

    var modalImage = event.target.closest ? event.target.closest('.js-modal-thumb') : null;
    if (modalImage && !modalImage.classList.contains('coolvideo-gallery-thumbnail')) {
      clearClassicModalVideo(modalImage.closest('.js-product-images-modal, #product-modal'));
    }

    var classicModalTrigger = event.target.closest
      ? event.target.closest('[data-target="#product-modal"], .js-qv-product-cover')
      : null;
    if (classicModalTrigger) {
      window.setTimeout(function () {
        injectProductGallery(false);
      }, 50);
      window.setTimeout(function () {
        injectProductGallery(false);
      }, 250);
    }
  }, true);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialise);
  } else {
    initialise();
  }

  window.addEventListener('load', function () {
    scheduleGalleryInjection(false);
    scheduleListingInjection(0);
  });

  if (window.prestashop && typeof window.prestashop.on === 'function') {
    window.prestashop.on('updatedProduct', function () {
      scheduleGalleryInjection(true);
    });
    window.prestashop.on('updateFacets', function () {
      scheduleListingInjection(50);
    });
    window.prestashop.on('quickviewOpened', function () {
      scheduleGalleryInjection(false);
    });
  }
})();
