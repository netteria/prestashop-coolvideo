/**
 * Cool Video Product
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

(function () {
  'use strict';

  if (window.__coolvideoAdminBound) {
    return;
  }
  window.__coolvideoAdminBound = true;

  function findRoot(element) {
    return element && element.closest ? element.closest('[data-coolvideo-admin]') : null;
  }

  function notify(type, message) {
    if (type === 'success' && typeof window.showSuccessMessage === 'function') {
      window.showSuccessMessage(message);
      return;
    }
    if (type === 'error' && typeof window.showErrorMessage === 'function') {
      window.showErrorMessage(message);
      return;
    }
    if (window.console) {
      window.console[type === 'error' ? 'error' : 'log'](message);
    }
  }

  function request(root, action, data) {
    var body = new URLSearchParams();
    var key;
    body.append('id_product', root.getAttribute('data-product-id'));

    for (key in data) {
      if (Object.prototype.hasOwnProperty.call(data, key)) {
        if (Array.isArray(data[key])) {
          data[key].forEach(function (value) {
            body.append(key + '[]', value);
          });
        } else {
          body.append(key, data[key]);
        }
      }
    }

    return window.fetch(root.getAttribute('data-ajax-url') + '&action=' + encodeURIComponent(action), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: body
    }).then(function (response) {
      return response.json().then(function (payload) {
        if (!response.ok || !payload.success) {
          var error = new Error(payload.message || root.getAttribute('data-error'));
          error.code = payload.code || '';
          error.upgradeUrl = payload.upgrade_url || '';
          throw error;
        }
        return payload;
      });
    });
  }

  function highlightUpgrade(root, error) {
    if (!root || !error || error.code !== 'upgrade_required') {
      return;
    }

    var upgrade = root.querySelector('[data-coolvideo-upgrade]');
    if (!upgrade) {
      return;
    }

    upgrade.classList.remove('coolvideo-upgrade-highlight');
    window.setTimeout(function () {
      upgrade.classList.add('coolvideo-upgrade-highlight');
      if (typeof upgrade.scrollIntoView === 'function') {
        upgrade.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }, 0);
  }

  function setBusy(button, busy) {
    if (!button) {
      return;
    }
    button.disabled = busy;
    button.setAttribute('aria-busy', busy ? 'true' : 'false');
  }

  function refreshEmptyState(root) {
    var empty = root.querySelector('[data-coolvideo-empty]');
    var hasVideos = !!root.querySelector('[data-video-id]');
    if (empty) {
      empty.classList.toggle('coolvideo-hidden', hasVideos);
    }
  }

  document.addEventListener('click', function (event) {
    var button = event.target.closest ? event.target.closest('[data-coolvideo-action]') : null;
    var root = findRoot(button);
    if (!button || !root) {
      return;
    }

    var action = button.getAttribute('data-coolvideo-action');
    if (action === 'savePosition') {
      var positionCard = button.closest('[data-video-id]');
      var positionInput = positionCard.querySelector('[data-coolvideo-position]');
      var position = Number(positionInput.value);
      if (!Number.isInteger(position) || position < 1 || position > 10000) {
        positionInput.focus();
        notify('error', root.getAttribute('data-error'));
        return;
      }

      setBusy(button, true);
      request(root, 'updatePosition', {
        id_video: positionCard.getAttribute('data-video-id'),
        position: position
      }).then(function (payload) {
        notify('success', payload.message);
        setBusy(button, false);
      }).catch(function (error) {
        notify('error', error.message);
        highlightUpgrade(root, error);
        setBusy(button, false);
      });
      return;
    }

    if (action === 'add') {
      var input = root.querySelector('#coolvideo-video-url');
      var url = input ? input.value.trim() : '';
      if (!url) {
        input.focus();
        return;
      }

      setBusy(button, true);
      request(root, 'add', { url: url })
        .then(function (payload) {
          notify('success', payload.message);
          window.location.reload();
        })
        .catch(function (error) {
          notify('error', error.message);
          highlightUpgrade(root, error);
          setBusy(button, false);
        });
      return;
    }

    if (action === 'delete') {
      if (!window.confirm(root.getAttribute('data-confirm-delete'))) {
        return;
      }

      var card = button.closest('[data-video-id]');
      setBusy(button, true);
      request(root, 'delete', { id_video: card.getAttribute('data-video-id') })
        .then(function (payload) {
          card.parentNode.removeChild(card);
          refreshEmptyState(root);
          notify('success', payload.message);
        })
        .catch(function (error) {
          notify('error', error.message);
          highlightUpgrade(root, error);
          setBusy(button, false);
        });
    }
  });

  document.addEventListener('change', function (event) {
    var checkbox = event.target;
    if (!checkbox.matches || !checkbox.matches('[data-coolvideo-toggle]')) {
      return;
    }

    var root = findRoot(checkbox);
    var card = checkbox.closest('[data-video-id]');
    var field = checkbox.getAttribute('data-coolvideo-toggle');
    var actionMap = {
      active: 'toggle',
      autostart: 'toggleAutostart',
      show_in_listing: 'toggleListing'
    };
    var data = { id_video: card.getAttribute('data-video-id') };
    data[field] = checkbox.checked ? 1 : 0;
    checkbox.disabled = true;

    request(root, actionMap[field], data)
      .then(function (payload) {
        notify('success', payload.message);
        checkbox.disabled = false;
      })
      .catch(function (error) {
        checkbox.checked = !checkbox.checked;
        checkbox.disabled = false;
        notify('error', error.message);
        highlightUpgrade(root, error);
      });
  });

})();
