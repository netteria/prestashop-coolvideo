{*
 * Cool Video Product
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 *}
{if !empty($coolvideo_videos)}
  <div class="coolvideo-extra-videos">
    {foreach from=$coolvideo_videos item=video}
      <article class="coolvideo-extra-video">
        <div class="coolvideo-responsive-video">
          <iframe
            src="{$video.embed_url|escape:'htmlall':'UTF-8'}"
            title="{$video.title|escape:'htmlall':'UTF-8'}"
            loading="lazy"
            allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowfullscreen
          ></iframe>
        </div>
        {if !empty($video.title)}
          <h3 class="coolvideo-extra-video-title">{$video.title|escape:'htmlall':'UTF-8'}</h3>
        {/if}
        {if !empty($video.description)}
          <p>{$video.description|strip_tags|escape:'htmlall':'UTF-8'}</p>
        {/if}
      </article>
    {/foreach}
  </div>
{/if}
