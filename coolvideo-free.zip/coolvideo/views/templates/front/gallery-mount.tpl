{*
 * Cool Video Product
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 *}
{* Hidden integration point used by the generic theme adapter. *}
<div
  class="coolvideo-theme-mount"
  data-coolvideo-mount="{$coolvideo_mount_product_id|intval}"
  data-coolvideo-videos="{$coolvideo_mount_videos_json|escape:'htmlall':'UTF-8'}"
  hidden
></div>
