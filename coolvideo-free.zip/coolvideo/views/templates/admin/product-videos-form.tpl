{*
 * Cool Video Product
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 *}
{* Product video manager rendered inside displayAdminProductsExtra. *}
{if !empty($coolvideo_back_css_url)}
  {* PS 8/9 can render this module after the Back Office head was built. *}
  <link rel="stylesheet" href="{$coolvideo_back_css_url|escape:'htmlall':'UTF-8'}" media="all">
{/if}
<section
  class="coolvideo-admin"
  data-coolvideo-admin
  data-ajax-url="{$coolvideo_ajax_url|escape:'htmlall':'UTF-8'}"
  data-product-id="{$coolvideo_id_product|intval}"
  data-confirm-delete="{l s='Delete this video?' mod='coolvideo' js=1}"
  data-error="{l s='The operation failed. Please try again.' mod='coolvideo' js=1}"
  data-free-edition="{if $coolvideo_is_free}1{else}0{/if}"
>
  <div class="coolvideo-admin-add form-group">
    <label for="coolvideo-video-url">{l s='Video URL' mod='coolvideo'}</label>
    <div class="input-group">
      <input
        id="coolvideo-video-url"
        class="form-control"
        type="url"
        maxlength="500"
        placeholder="https://www.youtube.com/watch?v=..."
        {if $coolvideo_is_free && !empty($coolvideo_videos)}disabled aria-describedby="coolvideo-free-limit"{/if}
      >
      <span class="input-group-btn input-group-append">
        <button class="btn btn-primary" type="button" data-coolvideo-action="add"{if $coolvideo_is_free && !empty($coolvideo_videos)} disabled{/if}>
          <i class="icon-plus" aria-hidden="true"></i>
          {l s='Add video' mod='coolvideo'}
        </button>
      </span>
    </div>
    {if $coolvideo_is_free}
      <p id="coolvideo-free-limit" class="help-block form-text text-muted coolvideo-free-summary">
        {l s='Free edition: one YouTube video per product.' mod='coolvideo'}
      </p>
      <ul class="coolvideo-pro-feature-preview">
        <li>
          <i class="icon-lock" aria-hidden="true"></i>
          {l s='Multiple videos per product' mod='coolvideo'}
          <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
        </li>
        <li>
          <i class="icon-lock" aria-hidden="true"></i>
          {l s='Vimeo and Dailymotion' mod='coolvideo'}
          <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
        </li>
        <li>
          <i class="icon-lock" aria-hidden="true"></i>
          {l s='Any gallery position' mod='coolvideo'}
          <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
        </li>
        <li>
          <i class="icon-lock" aria-hidden="true"></i>
          {l s='Autoplay (muted)' mod='coolvideo'}
          <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
        </li>
        <li>
          <i class="icon-lock" aria-hidden="true"></i>
          {l s='Show on product listings' mod='coolvideo'}
          <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
        </li>
      </ul>
    {else}
      <p class="help-block form-text text-muted">
        {l s='Supported services: YouTube, Vimeo and Dailymotion.' mod='coolvideo'}
      </p>
    {/if}
  </div>

  <div class="alert alert-info{if !empty($coolvideo_videos)} coolvideo-hidden{/if}" data-coolvideo-empty>
    {l s='No videos have been added to this product.' mod='coolvideo'}
  </div>

  {if !empty($coolvideo_videos) && !$coolvideo_is_free}
    <p class="help-block form-text text-muted">
      {l s='Gallery position includes both product photos and videos and is counted from 1: 1, 2, 3, 4...' mod='coolvideo'}
    </p>
  {/if}

  <div class="coolvideo-admin-grid" data-coolvideo-list>
    {foreach from=$coolvideo_videos item=video}
      <article
        class="coolvideo-admin-card"
        data-video-id="{$video.id_coolvideo_product_video|intval}"
      >
        <div class="coolvideo-admin-thumbnail">
          <img
            src="{$video.thumbnail_url|escape:'htmlall':'UTF-8'}"
            alt="{$video.title|escape:'htmlall':'UTF-8'}"
            loading="lazy"
          >
          <span class="coolvideo-admin-platform">{$video.platform|escape:'htmlall':'UTF-8'}</span>
        </div>
        <div class="coolvideo-admin-body">
          <strong>{$video.title|escape:'htmlall':'UTF-8'}</strong>
          <code>{$video.video_id|escape:'htmlall':'UTF-8'}</code>

          <div class="coolvideo-admin-position form-group{if !$coolvideo_capabilities.custom_position} coolvideo-admin-feature-locked{/if}">
            <label for="coolvideo-position-{$video.id_coolvideo_product_video|intval}">
              {l s='Gallery position' mod='coolvideo'}
              {if !$coolvideo_capabilities.custom_position}
                <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
              {/if}
            </label>
            <div class="input-group input-group-sm">
              {if $coolvideo_capabilities.custom_position}
                <input
                  id="coolvideo-position-{$video.id_coolvideo_product_video|intval}"
                  class="form-control"
                  type="number"
                  min="1"
                  max="10000"
                  step="1"
                  value="{$video.position|intval}"
                  data-coolvideo-position
                >
              {else}
                <input
                  id="coolvideo-position-{$video.id_coolvideo_product_video|intval}"
                  class="form-control"
                  type="text"
                  value="{l s='End of gallery' mod='coolvideo'}"
                  disabled
                  aria-describedby="coolvideo-position-help-{$video.id_coolvideo_product_video|intval}"
                >
              {/if}
              <span class="input-group-btn input-group-append">
                <button class="btn btn-default" type="button" data-coolvideo-action="savePosition"{if !$coolvideo_capabilities.custom_position} disabled{/if}>
                  {l s='Save position' mod='coolvideo'}
                </button>
              </span>
            </div>
            {if !$coolvideo_capabilities.custom_position}
              <small id="coolvideo-position-help-{$video.id_coolvideo_product_video|intval}" class="form-text text-muted">
                {l s='Choose any position, including the first gallery item, with Cool Video PRO.' mod='coolvideo'}
              </small>
            {/if}
          </div>

          <label class="coolvideo-admin-option">
            <input type="checkbox" data-coolvideo-toggle="active"{if $video.active} checked{/if}>
            {l s='Active' mod='coolvideo'}
          </label>
          <label class="coolvideo-admin-option{if !$coolvideo_capabilities.autoplay} coolvideo-admin-feature-locked{/if}">
            <input type="checkbox" data-coolvideo-toggle="autostart"{if $coolvideo_capabilities.autoplay && $video.autostart} checked{/if}{if !$coolvideo_capabilities.autoplay} disabled{/if}>
            {l s='Autoplay (muted)' mod='coolvideo'}
            {if !$coolvideo_capabilities.autoplay}
              <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
            {/if}
          </label>
          <label class="coolvideo-admin-option{if !$coolvideo_capabilities.product_listing} coolvideo-admin-feature-locked{/if}">
            <input type="checkbox" data-coolvideo-toggle="show_in_listing"{if $coolvideo_capabilities.product_listing && $video.show_in_listing} checked{/if}{if !$coolvideo_capabilities.product_listing} disabled{/if}>
            {l s='Show on product listings' mod='coolvideo'}
            {if !$coolvideo_capabilities.product_listing}
              <span class="coolvideo-pro-badge">{l s='Available in PRO' mod='coolvideo'}</span>
            {/if}
          </label>

          <button class="btn btn-danger btn-sm" type="button" data-coolvideo-action="delete">
            <i class="icon-trash" aria-hidden="true"></i>
            {l s='Delete' mod='coolvideo'}
          </button>
        </div>
      </article>
    {/foreach}
  </div>

  {if $coolvideo_is_free && !empty($coolvideo_upgrade_url)}
    <aside
      class="coolvideo-upgrade"
      data-coolvideo-upgrade
      style="max-width:880px;min-height:220px;overflow:hidden;background-color:#fff;background-image:url({$coolvideo_upgrade_image_url|escape:'htmlall':'UTF-8'});background-repeat:no-repeat;background-position:center;background-size:cover;"
    >
      <div class="coolvideo-upgrade-content" style="box-sizing:border-box;max-width:500px;padding:22px;background:rgba(255,255,255,.94);">
        <span class="coolvideo-upgrade-eyebrow">Cool Video PRO</span>
        <h3>{l s='Unlock the complete video gallery' mod='coolvideo'}</h3>
        <p>
          {l s='Add multiple videos, choose any gallery position, enable muted autoplay and show videos on product listings.' mod='coolvideo'}
        </p>
        <a
          class="btn btn-primary coolvideo-upgrade-button"
          href="{$coolvideo_upgrade_url|escape:'htmlall':'UTF-8'}"
          target="_blank"
          rel="noopener noreferrer"
          data-coolvideo-upgrade-link
        >
          <i class="icon-unlock" aria-hidden="true"></i>
          {l s='See Cool Video PRO' mod='coolvideo'}
        </a>
        <small>{l s='Upgrade without uninstalling Free. Your existing video will be preserved.' mod='coolvideo'}</small>
      </div>
    </aside>
  {/if}
</section>
{if !empty($coolvideo_back_js_url)}
  <script src="{$coolvideo_back_js_url|escape:'htmlall':'UTF-8'}"></script>
{/if}
