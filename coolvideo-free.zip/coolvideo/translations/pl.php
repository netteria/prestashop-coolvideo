<?php
/**
 * Polish classic translation dictionary for Cool Video.
 *
 * @author    Netteria.NET
 * @copyright Since 2025 Netteria.NET
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

global $_MODULE;
$_MODULE = [];

// Main module and controller wordings (default `coolvideo` context).
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Cool Video Free: Product Gallery Video')] = 'Cool Video Free: film w galerii produktu';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Adds one YouTube video to the end of each product gallery.')] = 'Dodaje jeden film YouTube na końcu galerii każdego produktu.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Cool Video: Product Gallery Videos and Autoplay')] = 'Cool Video: filmy w galerii produktu i autoplay';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Adds YouTube, Vimeo and Dailymotion videos to product galleries.')] = 'Dodaje filmy YouTube, Vimeo i Dailymotion do galerii produktów.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Do you really want to remove the module and all saved product videos?')] = 'Czy na pewno usunąć moduł i wszystkie zapisane filmy produktów?';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Product videos')] = 'Filmy produktów';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Product video')] = 'Film produktu';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Videos')] = 'Filmy';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Close video')] = 'Zamknij film';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Play video')] = 'Odtwórz film';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Invalid or unsupported video URL.')] = 'Nieprawidłowy lub nieobsługiwany adres filmu.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('This video service is available in Cool Video PRO. Cool Video Free supports YouTube.')] = 'Ten serwis wideo jest dostępny w Cool Video PRO. Cool Video Free obsługuje YouTube.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Cool Video Free allows one video per product. Add multiple videos with Cool Video PRO.')] = 'Cool Video Free pozwala dodać jeden film do produktu. W Cool Video PRO możesz dodać wiele filmów.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('The video could not be saved.')] = 'Nie udało się zapisać filmu.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Video added.')] = 'Film został dodany.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('The video could not be deleted.')] = 'Nie udało się usunąć filmu.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Video deleted.')] = 'Film został usunięty.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Custom gallery positions are available in Cool Video PRO. Free videos stay at the end of the gallery.')] = 'Dowolne pozycje galerii są dostępne w Cool Video PRO. W wersji Free film pozostaje na końcu galerii.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Invalid position data.')] = 'Nieprawidłowe dane pozycji.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Some positions could not be saved.')] = 'Nie udało się zapisać niektórych pozycji.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Positions saved.')] = 'Pozycje zostały zapisane.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Invalid gallery position.')] = 'Nieprawidłowa pozycja w galerii.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('The gallery position could not be saved.')] = 'Nie udało się zapisać pozycji w galerii.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Gallery position saved.')] = 'Pozycja w galerii została zapisana.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Muted autoplay is available in Cool Video PRO.')] = 'Wyciszone autoplay jest dostępne w Cool Video PRO.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Product-listing videos are available in Cool Video PRO.')] = 'Filmy na listach produktów są dostępne w Cool Video PRO.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('The video could not be updated.')] = 'Nie udało się zaktualizować filmu.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Video updated.')] = 'Film został zaktualizowany.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Video not found.')] = 'Nie znaleziono filmu.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Product not found.')] = 'Nie znaleziono produktu.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('Only POST requests are allowed.')] = 'Dozwolone są wyłącznie żądania POST.';
$_MODULE['<{coolvideo}prestashop>coolvideo_' . md5('You do not have permission to edit product videos.')] = 'Nie masz uprawnień do edycji filmów produktów.';

// Product video manager template (`product-videos-form.tpl` context).
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Delete this video?')] = 'Usunąć ten film?';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('The operation failed. Please try again.')] = 'Operacja nie powiodła się. Spróbuj ponownie.';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Video URL')] = 'Adres URL filmu';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Add video')] = 'Dodaj film';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Free edition: one YouTube video per product.')] = 'Wersja Free: jeden film YouTube na produkt.';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Vimeo and Dailymotion available in PRO')] = 'Vimeo i Dailymotion dostępne w wersji PRO';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Multiple videos per product')] = 'Wiele filmów na produkt';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Vimeo and Dailymotion')] = 'Vimeo i Dailymotion';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Any gallery position')] = 'Dowolna pozycja w galerii';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Supported services: YouTube, Vimeo and Dailymotion.')] = 'Obsługiwane serwisy: YouTube, Vimeo i Dailymotion.';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('No videos have been added to this product.')] = 'Do tego produktu nie dodano jeszcze filmów.';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Gallery position includes both product photos and videos and is counted from 1: 1, 2, 3, 4...')] = 'Pozycja w galerii obejmuje zdjęcia i filmy produktu oraz jest liczona od 1: 1, 2, 3, 4...';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Gallery position')] = 'Pozycja w galerii';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Available in PRO')] = 'Dostępne w wersji PRO';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('End of gallery')] = 'Na końcu galerii';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Save position')] = 'Zapisz pozycję';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Choose any position, including the first gallery item, with Cool Video PRO.')] = 'W Cool Video PRO możesz wybrać dowolną pozycję, również pierwszy element galerii.';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Active')] = 'Aktywny';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Autoplay (muted)')] = 'Autoplay (wyciszony)';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Show on product listings')] = 'Pokaż na listach produktów';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Delete')] = 'Usuń';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Unlock the complete video gallery')] = 'Odblokuj pełną galerię wideo';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Add multiple videos, choose any gallery position, enable muted autoplay and show videos on product listings.')] = 'Dodawaj wiele filmów, wybieraj dowolną pozycję, włączaj wyciszone autoplay i pokazuj filmy na listach produktów.';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('See Cool Video PRO')] = 'Zobacz Cool Video PRO';
$_MODULE['<{coolvideo}prestashop>product-videos-form_' . md5('Upgrade without uninstalling Free. Your existing video will be preserved.')] = 'Przejdź na PRO bez odinstalowywania Free. Zapisany film zostanie zachowany.';
